
# Task Graph Template

The CSV template defines one executable or governance task per row. Every task must include verification, proof, dependency metadata, rollback, model routing, and safe filesystem boundaries.

Required columns:

```text
task_id
parent_id
phase
title
goal
owner_lane
owner_agent
helper_id
model_tag
agent_runtime
shell_mode
repo_target
repo_path
filesystem_scope
input_files
target_files
target_artifacts
allowed_paths
blocked_paths
depends_on
blocks
parallel_group
can_run_parallel
max_parallel
start_after
priority
status
execution_cell
required_tools
command_template
verification_command
completion_gate
proof_required
proof_uri
heartbeat_file
logs_uri
rollback_plan
risk_level
human_approval_required
notes
```
