# Final Verification

Status: **failed**

Task count: 763
Execution packet count: 763
Proof count: 787

## Coverage
- system_inventory: covered via `ART-100_SYSTEM_INVENTORY`
- dependency_graph: covered via `ART-103_SERVICE_DEP_GRAPH`
- data_flow_graph: covered via `ART-107_DATA_FLOW_GRAPH`
- source_to_target_mapping: covered via `ART-109_DATA_LINEAGE`
- environment_matrix: covered via `ART-114_ENV_CONFIG_MATRIX`
- toolchain_dependency_tree: covered via `ART-104_TOOLCHAIN_TREE`
- api_event_contract_catalog: covered via `ART-110_API_CATALOG`
- cutover_checklist: covered via `ART-121_CUTOVER`
- rollback_plan: covered via `ART-122_ROLLBACK`
- risk_register: covered via `ART-125_RISK_REGISTER`
- decision_log: covered via `ART-126_DECISION_LOG`
- envctl_database: covered via `REQ-020_ENVCTL_DB_SCHEMA`
- nu_plugin: covered via `REQ-030_PLUGIN_PROTOCOL_MANIFEST`
- goal_loop: covered via `EF-007_GOAL_LOOP`
- proof_ledger: covered via `EF-008_VERIFY_HISTORY_COMPLETENESS`
- two_repo: covered via `REQ-041_TWO_REPO_INTEGRATION`
- flexnetos: covered via `REQ-201_FLEXNETOS_LIFEOS_COMPARISON`

## External blockers
- `EXT-DRIVE-WRITE`: Authenticated Google Drive file edit/revision API is not available in this environment; upgraded package archive is produced for upload/application to Drive.

## Missing outputs
[]

## Tasks without packets
[]

## Packet missing fields
[]

## Unresolved implementation obligations
[
  {
    "task_id": "ANCHOR-A01_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A01_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A02_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A02_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A03_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A03_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A04_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A04_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A05_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A05_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A06_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A06_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A07_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A07_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A08_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A08_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A09_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A09_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A10_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A10_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A11_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A11_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A12_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A12_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A13_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A13_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A14_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A14_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A15_LEDGER_ROW",
    "packet": "generated/execution_packets/ANCHOR-A15_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-001_POSTGRESQL",
    "packet": "generated/execution_packets/COMPONENT-001_POSTGRESQL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-002_RUVECTOR_POSTGRESQL_EXTENSION",
    "packet": "generated/execution_packets/COMPONENT-002_RUVECTOR_POSTGRESQL_EXTENSION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-003_RUVECTOR_CORE_SERVICE_RUNTIME",
    "packet": "generated/execution_packets/COMPONENT-003_RUVECTOR_CORE_SERVICE_RUNTIME.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-004_RUVECTOR_RETRIEVAL_INDEX_FAMILY",
    "packet": "generated/execution_packets/COMPONENT-004_RUVECTOR_RETRIEVAL_INDEX_FAMILY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-005_RUVECTOR_GRAPH_RDF_DAG_FAMILY",
    "packet": "generated/execution_packets/COMPONENT-005_RUVECTOR_GRAPH_RDF_DAG_FAMILY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-006_RUVECTOR_GNN_ATTENTION_CNN_FAMILY",
    "packet": "generated/execution_packets/COMPONENT-006_RUVECTOR_GNN_ATTENTION_CNN_FAMILY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-007_RUVECTOR_MINCUT_HEALING_PERCEPTION_FAMILY",
    "packet": "generated/execution_packets/COMPONENT-007_RUVECTOR_MINCUT_HEALING_PERCEPTION_FAMILY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-008_FASTGRNN_AND_TINY_DANCER_ROUTING",
    "packet": "generated/execution_packets/COMPONENT-008_FASTGRNN_AND_TINY_DANCER_ROUTING.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-009_SONA_AND_REINFORCEMENT_LEARNING",
    "packet": "generated/execution_packets/COMPONENT-009_SONA_AND_REINFORCEMENT_LEARNING.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-010_RUVLLM_AND_RUVLTRA",
    "packet": "generated/execution_packets/COMPONENT-010_RUVLLM_AND_RUVLTRA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-011_AGENTDB",
    "packet": "generated/execution_packets/COMPONENT-011_AGENTDB.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-012_RVF",
    "packet": "generated/execution_packets/COMPONENT-012_RVF.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-013_PROOF_AND_WITNESS_RUNTIME",
    "packet": "generated/execution_packets/COMPONENT-013_PROOF_AND_WITNESS_RUNTIME.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-014_RUFLO",
    "packet": "generated/execution_packets/COMPONENT-014_RUFLO.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-015_ATAS",
    "packet": "generated/execution_packets/COMPONENT-015_ATAS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-016_REDB",
    "packet": "generated/execution_packets/COMPONENT-016_REDB.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-017_ENVCTL",
    "packet": "generated/execution_packets/COMPONENT-017_ENVCTL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-018_SECRET_ENGINE",
    "packet": "generated/execution_packets/COMPONENT-018_SECRET_ENGINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-019_SECRET_BROKER",
    "packet": "generated/execution_packets/COMPONENT-019_SECRET_BROKER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-020_SECRET_MINT",
    "packet": "generated/execution_packets/COMPONENT-020_SECRET_MINT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-021_SEED_VAULT",
    "packet": "generated/execution_packets/COMPONENT-021_SEED_VAULT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-022_COGNITUM_SEED",
    "packet": "generated/execution_packets/COMPONENT-022_COGNITUM_SEED.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-023_SECRET_RELAY",
    "packet": "generated/execution_packets/COMPONENT-023_SECRET_RELAY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-024_NU_PLUGIN_CODEDB",
    "packet": "generated/execution_packets/COMPONENT-024_NU_PLUGIN_CODEDB.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-025_RTK",
    "packet": "generated/execution_packets/COMPONENT-025_RTK.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-026_RTK_NU",
    "packet": "generated/execution_packets/COMPONENT-026_RTK_NU.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-027_NUSHELL",
    "packet": "generated/execution_packets/COMPONENT-027_NUSHELL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-028_YAZELIX_ZELLIJ_HELIX_YAZI_NEOVIM",
    "packet": "generated/execution_packets/COMPONENT-028_YAZELIX_ZELLIJ_HELIX_YAZI_NEOVIM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-029_LIFEOS_AND_CODEX",
    "packet": "generated/execution_packets/COMPONENT-029_LIFEOS_AND_CODEX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-030_GIT_GITKB_META_BEADS_BR",
    "packet": "generated/execution_packets/COMPONENT-030_GIT_GITKB_META_BEADS_BR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-031_ICM",
    "packet": "generated/execution_packets/COMPONENT-031_ICM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-032_WEAVE",
    "packet": "generated/execution_packets/COMPONENT-032_WEAVE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-033_NETWORK_CONTROL",
    "packet": "generated/execution_packets/COMPONENT-033_NETWORK_CONTROL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-034_FLEXNETOS_RUNNER",
    "packet": "generated/execution_packets/COMPONENT-034_FLEXNETOS_RUNNER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-035_RUSTY_IDD_HF",
    "packet": "generated/execution_packets/COMPONENT-035_RUSTY_IDD_HF.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-036_NIX_COMPILERS_BUN_NAPI_WASM_AND_MUSL",
    "packet": "generated/execution_packets/COMPONENT-036_NIX_COMPILERS_BUN_NAPI_WASM_AND_MUSL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-037_GPU_ONNX_CANDLE_AND_MODEL_DRIVERS",
    "packet": "generated/execution_packets/COMPONENT-037_GPU_ONNX_CANDLE_AND_MODEL_DRIVERS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-038_RUVIX_RVAGENT_HARDWARE_AND_SPECIALIZED_RUVEC",
    "packet": "generated/execution_packets/COMPONENT-038_RUVIX_RVAGENT_HARDWARE_AND_SPECIALIZED_RUVEC.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-039_RUVECTOR_MEMBER_RUVECTOR_TEMPORAL_COHERENCE",
    "packet": "generated/execution_packets/COMPONENT-039_RUVECTOR_MEMBER_RUVECTOR_TEMPORAL_COHERENCE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-040_RUVECTOR_MEMBER_RUVECTOR_ACORN",
    "packet": "generated/execution_packets/COMPONENT-040_RUVECTOR_MEMBER_RUVECTOR_ACORN.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-041_RUVECTOR_MEMBER_RUVECTOR_ACORN_WASM",
    "packet": "generated/execution_packets/COMPONENT-041_RUVECTOR_MEMBER_RUVECTOR_ACORN_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-042_RUVECTOR_MEMBER_RUVECTOR_COHERENCE_HNSW",
    "packet": "generated/execution_packets/COMPONENT-042_RUVECTOR_MEMBER_RUVECTOR_COHERENCE_HNSW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-043_RUVECTOR_MEMBER_RUVECTOR_RABITQ",
    "packet": "generated/execution_packets/COMPONENT-043_RUVECTOR_MEMBER_RUVECTOR_RABITQ.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-044_RUVECTOR_MEMBER_RUVECTOR_RABITQ_WASM",
    "packet": "generated/execution_packets/COMPONENT-044_RUVECTOR_MEMBER_RUVECTOR_RABITQ_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-045_RUVECTOR_MEMBER_RUVECTOR_RULAKE",
    "packet": "generated/execution_packets/COMPONENT-045_RUVECTOR_MEMBER_RUVECTOR_RULAKE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-046_RUVECTOR_MEMBER_RUVECTOR_CORE",
    "packet": "generated/execution_packets/COMPONENT-046_RUVECTOR_MEMBER_RUVECTOR_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-047_RUVECTOR_MEMBER_RUVECTOR_NODE",
    "packet": "generated/execution_packets/COMPONENT-047_RUVECTOR_MEMBER_RUVECTOR_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-048_RUVECTOR_MEMBER_RUVECTOR_WASM",
    "packet": "generated/execution_packets/COMPONENT-048_RUVECTOR_MEMBER_RUVECTOR_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-049_RUVECTOR_MEMBER_RUVECTOR_CLI",
    "packet": "generated/execution_packets/COMPONENT-049_RUVECTOR_MEMBER_RUVECTOR_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-050_RUVECTOR_MEMBER_RUVECTOR_BENCH",
    "packet": "generated/execution_packets/COMPONENT-050_RUVECTOR_MEMBER_RUVECTOR_BENCH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-051_RUVECTOR_MEMBER_RUVECTOR_METRICS",
    "packet": "generated/execution_packets/COMPONENT-051_RUVECTOR_MEMBER_RUVECTOR_METRICS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-052_RUVECTOR_MEMBER_RUVECTOR_FILTER",
    "packet": "generated/execution_packets/COMPONENT-052_RUVECTOR_MEMBER_RUVECTOR_FILTER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-053_RUVECTOR_MEMBER_RUVECTOR_ROUTER_CORE",
    "packet": "generated/execution_packets/COMPONENT-053_RUVECTOR_MEMBER_RUVECTOR_ROUTER_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-054_RUVECTOR_MEMBER_RUVECTOR_ROUTER_CLI",
    "packet": "generated/execution_packets/COMPONENT-054_RUVECTOR_MEMBER_RUVECTOR_ROUTER_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-055_RUVECTOR_MEMBER_RUVECTOR_ROUTER_FFI",
    "packet": "generated/execution_packets/COMPONENT-055_RUVECTOR_MEMBER_RUVECTOR_ROUTER_FFI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-056_RUVECTOR_MEMBER_RUVECTOR_ROUTER_WASM",
    "packet": "generated/execution_packets/COMPONENT-056_RUVECTOR_MEMBER_RUVECTOR_ROUTER_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-057_RUVECTOR_MEMBER_RUVECTOR_SERVER",
    "packet": "generated/execution_packets/COMPONENT-057_RUVECTOR_MEMBER_RUVECTOR_SERVER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-058_RUVECTOR_MEMBER_RUVECTOR_SNAPSHOT",
    "packet": "generated/execution_packets/COMPONENT-058_RUVECTOR_MEMBER_RUVECTOR_SNAPSHOT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-059_RUVECTOR_MEMBER_RUVECTOR_TINY_DANCER_CORE",
    "packet": "generated/execution_packets/COMPONENT-059_RUVECTOR_MEMBER_RUVECTOR_TINY_DANCER_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-060_RUVECTOR_MEMBER_RUVECTOR_TINY_DANCER_WASM",
    "packet": "generated/execution_packets/COMPONENT-060_RUVECTOR_MEMBER_RUVECTOR_TINY_DANCER_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-061_RUVECTOR_MEMBER_RUVECTOR_TINY_DANCER_NODE",
    "packet": "generated/execution_packets/COMPONENT-061_RUVECTOR_MEMBER_RUVECTOR_TINY_DANCER_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-062_RUVECTOR_MEMBER_RUVECTOR_COLLECTIONS",
    "packet": "generated/execution_packets/COMPONENT-062_RUVECTOR_MEMBER_RUVECTOR_COLLECTIONS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-063_RUVECTOR_MEMBER_RUVECTOR_CLUSTER",
    "packet": "generated/execution_packets/COMPONENT-063_RUVECTOR_MEMBER_RUVECTOR_CLUSTER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-064_RUVECTOR_MEMBER_RUVECTOR_RAFT",
    "packet": "generated/execution_packets/COMPONENT-064_RUVECTOR_MEMBER_RUVECTOR_RAFT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-065_RUVECTOR_MEMBER_RUVECTOR_REPLICATION",
    "packet": "generated/execution_packets/COMPONENT-065_RUVECTOR_MEMBER_RUVECTOR_REPLICATION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-066_RUVECTOR_MEMBER_RUVECTOR_GRAPH",
    "packet": "generated/execution_packets/COMPONENT-066_RUVECTOR_MEMBER_RUVECTOR_GRAPH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-067_RUVECTOR_MEMBER_RUVECTOR_GRAPH_NODE",
    "packet": "generated/execution_packets/COMPONENT-067_RUVECTOR_MEMBER_RUVECTOR_GRAPH_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-068_RUVECTOR_MEMBER_RUVECTOR_GRAPH_WASM",
    "packet": "generated/execution_packets/COMPONENT-068_RUVECTOR_MEMBER_RUVECTOR_GRAPH_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-069_RUVECTOR_MEMBER_RUVECTOR_GNN",
    "packet": "generated/execution_packets/COMPONENT-069_RUVECTOR_MEMBER_RUVECTOR_GNN.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-070_RUVECTOR_MEMBER_RUVECTOR_PROOF_GATE",
    "packet": "generated/execution_packets/COMPONENT-070_RUVECTOR_MEMBER_RUVECTOR_PROOF_GATE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-071_RUVECTOR_MEMBER_RUVECTOR_GNN_RERANK",
    "packet": "generated/execution_packets/COMPONENT-071_RUVECTOR_MEMBER_RUVECTOR_GNN_RERANK.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-072_RUVECTOR_MEMBER_RUVECTOR_GNN_NODE",
    "packet": "generated/execution_packets/COMPONENT-072_RUVECTOR_MEMBER_RUVECTOR_GNN_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-073_RUVECTOR_MEMBER_RUVECTOR_GNN_WASM",
    "packet": "generated/execution_packets/COMPONENT-073_RUVECTOR_MEMBER_RUVECTOR_GNN_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-074_RUVECTOR_MEMBER_RUVECTOR_ATTENTION",
    "packet": "generated/execution_packets/COMPONENT-074_RUVECTOR_MEMBER_RUVECTOR_ATTENTION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-075_RUVECTOR_MEMBER_RUVECTOR_ATTENTION_WASM",
    "packet": "generated/execution_packets/COMPONENT-075_RUVECTOR_MEMBER_RUVECTOR_ATTENTION_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-076_RUVECTOR_MEMBER_RUVECTOR_ATTENTION_NODE",
    "packet": "generated/execution_packets/COMPONENT-076_RUVECTOR_MEMBER_RUVECTOR_ATTENTION_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-077_RUVECTOR_MEMBER_RUVECTOR_CNN",
    "packet": "generated/execution_packets/COMPONENT-077_RUVECTOR_MEMBER_RUVECTOR_CNN.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-078_RUVECTOR_MEMBER_RUVECTOR_CNN_WASM",
    "packet": "generated/execution_packets/COMPONENT-078_RUVECTOR_MEMBER_RUVECTOR_CNN_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-079_RUVECTOR_MEMBER_RUVECTOR_MINCUT",
    "packet": "generated/execution_packets/COMPONENT-079_RUVECTOR_MEMBER_RUVECTOR_MINCUT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-080_RUVECTOR_MEMBER_RUVECTOR_MINCUT_WASM",
    "packet": "generated/execution_packets/COMPONENT-080_RUVECTOR_MEMBER_RUVECTOR_MINCUT_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-081_RUVECTOR_MEMBER_RUVECTOR_MINCUT_NODE",
    "packet": "generated/execution_packets/COMPONENT-081_RUVECTOR_MEMBER_RUVECTOR_MINCUT_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-082_RUVECTOR_MEMBER_RUVECTOR_MINCUT_GATED_TRANSF",
    "packet": "generated/execution_packets/COMPONENT-082_RUVECTOR_MEMBER_RUVECTOR_MINCUT_GATED_TRANSF.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-083_RUVECTOR_MEMBER_RUVECTOR_MINCUT_GATED_TRANSF",
    "packet": "generated/execution_packets/COMPONENT-083_RUVECTOR_MEMBER_RUVECTOR_MINCUT_GATED_TRANSF.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-084_RUVECTOR_MEMBER_RUVECTOR_NERVOUS_SYSTEM",
    "packet": "generated/execution_packets/COMPONENT-084_RUVECTOR_MEMBER_RUVECTOR_NERVOUS_SYSTEM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-085_RUVECTOR_MEMBER_HAILORT_SYS",
    "packet": "generated/execution_packets/COMPONENT-085_RUVECTOR_MEMBER_HAILORT_SYS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-086_RUVECTOR_MEMBER_RUVECTOR_HAILO",
    "packet": "generated/execution_packets/COMPONENT-086_RUVECTOR_MEMBER_RUVECTOR_HAILO.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-087_RUVECTOR_MEMBER_RUVECTOR_MMWAVE",
    "packet": "generated/execution_packets/COMPONENT-087_RUVECTOR_MEMBER_RUVECTOR_MMWAVE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-088_RUVECTOR_MEMBER_RUVECTOR_HAILO_CLUSTER",
    "packet": "generated/execution_packets/COMPONENT-088_RUVECTOR_MEMBER_RUVECTOR_HAILO_CLUSTER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-089_RUVECTOR_MEMBER_REFRAG_PIPELINE",
    "packet": "generated/execution_packets/COMPONENT-089_RUVECTOR_MEMBER_REFRAG_PIPELINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-090_RUVECTOR_MEMBER_SCIPIX",
    "packet": "generated/execution_packets/COMPONENT-090_RUVECTOR_MEMBER_SCIPIX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-091_RUVECTOR_MEMBER_GOOGLE_CLOUD",
    "packet": "generated/execution_packets/COMPONENT-091_RUVECTOR_MEMBER_GOOGLE_CLOUD.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-092_RUVECTOR_MEMBER_SUBPOLYNOMIAL_TIME",
    "packet": "generated/execution_packets/COMPONENT-092_RUVECTOR_MEMBER_SUBPOLYNOMIAL_TIME.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-093_RUVECTOR_MEMBER_RUVECTOR_SONA",
    "packet": "generated/execution_packets/COMPONENT-093_RUVECTOR_MEMBER_RUVECTOR_SONA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-094_RUVECTOR_MEMBER_RVLITE",
    "packet": "generated/execution_packets/COMPONENT-094_RUVECTOR_MEMBER_RVLITE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-095_RUVECTOR_MEMBER_RUVECTOR_DAG",
    "packet": "generated/execution_packets/COMPONENT-095_RUVECTOR_MEMBER_RUVECTOR_DAG.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-096_RUVECTOR_MEMBER_RUVECTOR_DAG_WASM",
    "packet": "generated/execution_packets/COMPONENT-096_RUVECTOR_MEMBER_RUVECTOR_DAG_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-097_RUVECTOR_MEMBER_RUVECTOR_NERVOUS_SYSTEM_WASM",
    "packet": "generated/execution_packets/COMPONENT-097_RUVECTOR_MEMBER_RUVECTOR_NERVOUS_SYSTEM_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-098_RUVECTOR_MEMBER_RUVECTOR_ECONOMY_WASM",
    "packet": "generated/execution_packets/COMPONENT-098_RUVECTOR_MEMBER_RUVECTOR_ECONOMY_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-099_RUVECTOR_MEMBER_RUVECTOR_LEARNING_WASM",
    "packet": "generated/execution_packets/COMPONENT-099_RUVECTOR_MEMBER_RUVECTOR_LEARNING_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-100_RUVECTOR_MEMBER_RUVECTOR_EXOTIC_WASM",
    "packet": "generated/execution_packets/COMPONENT-100_RUVECTOR_MEMBER_RUVECTOR_EXOTIC_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-101_RUVECTOR_MEMBER_RUVECTOR_ATTENTION_UNIFIED_W",
    "packet": "generated/execution_packets/COMPONENT-101_RUVECTOR_MEMBER_RUVECTOR_ATTENTION_UNIFIED_W.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-102_RUVECTOR_MEMBER_RUVECTOR_FPGA_TRANSFORMER",
    "packet": "generated/execution_packets/COMPONENT-102_RUVECTOR_MEMBER_RUVECTOR_FPGA_TRANSFORMER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-103_RUVECTOR_MEMBER_RUVECTOR_FPGA_TRANSFORMER_WA",
    "packet": "generated/execution_packets/COMPONENT-103_RUVECTOR_MEMBER_RUVECTOR_FPGA_TRANSFORMER_WA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-104_RUVECTOR_MEMBER_RUVECTOR_SPARSE_INFERENCE",
    "packet": "generated/execution_packets/COMPONENT-104_RUVECTOR_MEMBER_RUVECTOR_SPARSE_INFERENCE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-105_RUVECTOR_MEMBER_RUVECTOR_MATH",
    "packet": "generated/execution_packets/COMPONENT-105_RUVECTOR_MEMBER_RUVECTOR_MATH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-106_RUVECTOR_MEMBER_RUVECTOR_MATH_WASM",
    "packet": "generated/execution_packets/COMPONENT-106_RUVECTOR_MEMBER_RUVECTOR_MATH_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-107_RUVECTOR_MEMBER_BENCHMARKS",
    "packet": "generated/execution_packets/COMPONENT-107_RUVECTOR_MEMBER_BENCHMARKS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-108_RUVECTOR_MEMBER_COGNITUM_GATE_KERNEL",
    "packet": "generated/execution_packets/COMPONENT-108_RUVECTOR_MEMBER_COGNITUM_GATE_KERNEL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-109_RUVECTOR_MEMBER_COGNITUM_GATE_TILEZERO",
    "packet": "generated/execution_packets/COMPONENT-109_RUVECTOR_MEMBER_COGNITUM_GATE_TILEZERO.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-110_RUVECTOR_MEMBER_MCP_GATE",
    "packet": "generated/execution_packets/COMPONENT-110_RUVECTOR_MEMBER_MCP_GATE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-111_RUVECTOR_MEMBER_MCP_BRAIN",
    "packet": "generated/execution_packets/COMPONENT-111_RUVECTOR_MEMBER_MCP_BRAIN.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-112_RUVECTOR_MEMBER_MCP_BRAIN_SERVER",
    "packet": "generated/execution_packets/COMPONENT-112_RUVECTOR_MEMBER_MCP_BRAIN_SERVER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-113_RUVECTOR_MEMBER_RUVLLM",
    "packet": "generated/execution_packets/COMPONENT-113_RUVECTOR_MEMBER_RUVLLM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-114_RUVECTOR_MEMBER_RUVLLM_CLI",
    "packet": "generated/execution_packets/COMPONENT-114_RUVECTOR_MEMBER_RUVLLM_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-115_RUVECTOR_MEMBER_RUVLLM_WASM",
    "packet": "generated/execution_packets/COMPONENT-115_RUVECTOR_MEMBER_RUVLLM_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-116_RUVECTOR_MEMBER_PRIME_RADIANT",
    "packet": "generated/execution_packets/COMPONENT-116_RUVECTOR_MEMBER_PRIME_RADIANT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-117_RUVECTOR_MEMBER_RUVECTOR_DELTA_CORE",
    "packet": "generated/execution_packets/COMPONENT-117_RUVECTOR_MEMBER_RUVECTOR_DELTA_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-118_RUVECTOR_MEMBER_RUVECTOR_DELTA_WASM",
    "packet": "generated/execution_packets/COMPONENT-118_RUVECTOR_MEMBER_RUVECTOR_DELTA_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-119_RUVECTOR_MEMBER_RUVECTOR_DELTA_INDEX",
    "packet": "generated/execution_packets/COMPONENT-119_RUVECTOR_MEMBER_RUVECTOR_DELTA_INDEX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-120_RUVECTOR_MEMBER_RUVECTOR_DELTA_GRAPH",
    "packet": "generated/execution_packets/COMPONENT-120_RUVECTOR_MEMBER_RUVECTOR_DELTA_GRAPH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-121_RUVECTOR_MEMBER_RUVECTOR_DELTA_CONSENSUS",
    "packet": "generated/execution_packets/COMPONENT-121_RUVECTOR_MEMBER_RUVECTOR_DELTA_CONSENSUS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-122_RUVECTOR_MEMBER_RUVECTOR_CRV",
    "packet": "generated/execution_packets/COMPONENT-122_RUVECTOR_MEMBER_RUVECTOR_CRV.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-123_RUVECTOR_MEMBER_RUVECTOR_TEMPORAL_TENSOR",
    "packet": "generated/execution_packets/COMPONENT-123_RUVECTOR_MEMBER_RUVECTOR_TEMPORAL_TENSOR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-124_RUVECTOR_MEMBER_RUVECTOR_DOMAIN_EXPANSION",
    "packet": "generated/execution_packets/COMPONENT-124_RUVECTOR_MEMBER_RUVECTOR_DOMAIN_EXPANSION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-125_RUVECTOR_MEMBER_RUVECTOR_DOMAIN_EXPANSION_WA",
    "packet": "generated/execution_packets/COMPONENT-125_RUVECTOR_MEMBER_RUVECTOR_DOMAIN_EXPANSION_WA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-126_RUVECTOR_MEMBER_RUVECTOR_SOLVER",
    "packet": "generated/execution_packets/COMPONENT-126_RUVECTOR_MEMBER_RUVECTOR_SOLVER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-127_RUVECTOR_MEMBER_RUVECTOR_SOLVER_WASM",
    "packet": "generated/execution_packets/COMPONENT-127_RUVECTOR_MEMBER_RUVECTOR_SOLVER_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-128_RUVECTOR_MEMBER_RUVECTOR_SOLVER_NODE",
    "packet": "generated/execution_packets/COMPONENT-128_RUVECTOR_MEMBER_RUVECTOR_SOLVER_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-129_RUVECTOR_MEMBER_RUVECTOR_COHERENCE",
    "packet": "generated/execution_packets/COMPONENT-129_RUVECTOR_MEMBER_RUVECTOR_COHERENCE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-130_RUVECTOR_MEMBER_RUVECTOR_PROFILER",
    "packet": "generated/execution_packets/COMPONENT-130_RUVECTOR_MEMBER_RUVECTOR_PROFILER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-131_RUVECTOR_MEMBER_RUVECTOR_ATTN_MINCUT",
    "packet": "generated/execution_packets/COMPONENT-131_RUVECTOR_MEMBER_RUVECTOR_ATTN_MINCUT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-132_RUVECTOR_MEMBER_RUVECTOR_COGNITIVE_CONTAINER",
    "packet": "generated/execution_packets/COMPONENT-132_RUVECTOR_MEMBER_RUVECTOR_COGNITIVE_CONTAINER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-133_RUVECTOR_MEMBER_RUVECTOR_VERIFIED",
    "packet": "generated/execution_packets/COMPONENT-133_RUVECTOR_MEMBER_RUVECTOR_VERIFIED.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-134_RUVECTOR_MEMBER_RUVECTOR_VERIFIED_WASM",
    "packet": "generated/execution_packets/COMPONENT-134_RUVECTOR_MEMBER_RUVECTOR_VERIFIED_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-135_RUVECTOR_MEMBER_RUVECTOR_GRAPH_TRANSFORMER",
    "packet": "generated/execution_packets/COMPONENT-135_RUVECTOR_MEMBER_RUVECTOR_GRAPH_TRANSFORMER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-136_RUVECTOR_MEMBER_RUVECTOR_GRAPH_TRANSFORMER_W",
    "packet": "generated/execution_packets/COMPONENT-136_RUVECTOR_MEMBER_RUVECTOR_GRAPH_TRANSFORMER_W.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-137_RUVECTOR_MEMBER_RUVECTOR_GRAPH_TRANSFORMER_N",
    "packet": "generated/execution_packets/COMPONENT-137_RUVECTOR_MEMBER_RUVECTOR_GRAPH_TRANSFORMER_N.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-138_RUVECTOR_MEMBER_RVF_KERNEL_OPTIMIZED",
    "packet": "generated/execution_packets/COMPONENT-138_RUVECTOR_MEMBER_RVF_KERNEL_OPTIMIZED.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-139_RUVECTOR_MEMBER_VERIFIED_APPLICATIONS",
    "packet": "generated/execution_packets/COMPONENT-139_RUVECTOR_MEMBER_VERIFIED_APPLICATIONS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-140_RUVECTOR_MEMBER_THERMORUST",
    "packet": "generated/execution_packets/COMPONENT-140_RUVECTOR_MEMBER_THERMORUST.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-141_RUVECTOR_MEMBER_RUVECTOR_DITHER",
    "packet": "generated/execution_packets/COMPONENT-141_RUVECTOR_MEMBER_RUVECTOR_DITHER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-142_RUVECTOR_MEMBER_RUVECTOR_ROBOTICS",
    "packet": "generated/execution_packets/COMPONENT-142_RUVECTOR_MEMBER_RUVECTOR_ROBOTICS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-143_RUVECTOR_MEMBER_ROBOTICS",
    "packet": "generated/execution_packets/COMPONENT-143_RUVECTOR_MEMBER_ROBOTICS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-144_RUVECTOR_MEMBER_NEURAL_TRADER_CORE",
    "packet": "generated/execution_packets/COMPONENT-144_RUVECTOR_MEMBER_NEURAL_TRADER_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-145_RUVECTOR_MEMBER_NEURAL_TRADER_COHERENCE",
    "packet": "generated/execution_packets/COMPONENT-145_RUVECTOR_MEMBER_NEURAL_TRADER_COHERENCE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-146_RUVECTOR_MEMBER_NEURAL_TRADER_REPLAY",
    "packet": "generated/execution_packets/COMPONENT-146_RUVECTOR_MEMBER_NEURAL_TRADER_REPLAY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-147_RUVECTOR_MEMBER_NEURAL_TRADER_WASM",
    "packet": "generated/execution_packets/COMPONENT-147_RUVECTOR_MEMBER_NEURAL_TRADER_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-148_RUVECTOR_MEMBER_RUVECTOR_KALSHI",
    "packet": "generated/execution_packets/COMPONENT-148_RUVECTOR_MEMBER_RUVECTOR_KALSHI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-149_RUVECTOR_MEMBER_NEURAL_TRADER_STRATEGIES",
    "packet": "generated/execution_packets/COMPONENT-149_RUVECTOR_MEMBER_NEURAL_TRADER_STRATEGIES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-150_RUVECTOR_MEMBER_TYPES",
    "packet": "generated/execution_packets/COMPONENT-150_RUVECTOR_MEMBER_TYPES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-151_RUVECTOR_MEMBER_REGION",
    "packet": "generated/execution_packets/COMPONENT-151_RUVECTOR_MEMBER_REGION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-152_RUVECTOR_MEMBER_QUEUE",
    "packet": "generated/execution_packets/COMPONENT-152_RUVECTOR_MEMBER_QUEUE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-153_RUVECTOR_MEMBER_CAP",
    "packet": "generated/execution_packets/COMPONENT-153_RUVECTOR_MEMBER_CAP.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-154_RUVECTOR_MEMBER_PROOF",
    "packet": "generated/execution_packets/COMPONENT-154_RUVECTOR_MEMBER_PROOF.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-155_RUVECTOR_MEMBER_SCHED",
    "packet": "generated/execution_packets/COMPONENT-155_RUVECTOR_MEMBER_SCHED.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-156_RUVECTOR_MEMBER_BOOT",
    "packet": "generated/execution_packets/COMPONENT-156_RUVECTOR_MEMBER_BOOT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-157_RUVECTOR_MEMBER_VECGRAPH",
    "packet": "generated/execution_packets/COMPONENT-157_RUVECTOR_MEMBER_VECGRAPH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-158_RUVECTOR_MEMBER_NUCLEUS",
    "packet": "generated/execution_packets/COMPONENT-158_RUVECTOR_MEMBER_NUCLEUS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-159_RUVECTOR_MEMBER_HAL",
    "packet": "generated/execution_packets/COMPONENT-159_RUVECTOR_MEMBER_HAL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-160_RUVECTOR_MEMBER_AARCH64",
    "packet": "generated/execution_packets/COMPONENT-160_RUVECTOR_MEMBER_AARCH64.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-161_RUVECTOR_MEMBER_DRIVERS",
    "packet": "generated/execution_packets/COMPONENT-161_RUVECTOR_MEMBER_DRIVERS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-162_RUVECTOR_MEMBER_TESTS",
    "packet": "generated/execution_packets/COMPONENT-162_RUVECTOR_MEMBER_TESTS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-163_RUVECTOR_MEMBER_BENCHES",
    "packet": "generated/execution_packets/COMPONENT-163_RUVECTOR_MEMBER_BENCHES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-164_RUVECTOR_MEMBER_COGNITIVE_DEMO",
    "packet": "generated/execution_packets/COMPONENT-164_RUVECTOR_MEMBER_COGNITIVE_DEMO.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-165_RUVECTOR_MEMBER_RVAGENT_CORE",
    "packet": "generated/execution_packets/COMPONENT-165_RUVECTOR_MEMBER_RVAGENT_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-166_RUVECTOR_MEMBER_RVAGENT_BACKENDS",
    "packet": "generated/execution_packets/COMPONENT-166_RUVECTOR_MEMBER_RVAGENT_BACKENDS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-167_RUVECTOR_MEMBER_RVAGENT_MIDDLEWARE",
    "packet": "generated/execution_packets/COMPONENT-167_RUVECTOR_MEMBER_RVAGENT_MIDDLEWARE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-168_RUVECTOR_MEMBER_RVAGENT_TOOLS",
    "packet": "generated/execution_packets/COMPONENT-168_RUVECTOR_MEMBER_RVAGENT_TOOLS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-169_RUVECTOR_MEMBER_RVAGENT_SUBAGENTS",
    "packet": "generated/execution_packets/COMPONENT-169_RUVECTOR_MEMBER_RVAGENT_SUBAGENTS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-170_RUVECTOR_MEMBER_RVAGENT_CLI",
    "packet": "generated/execution_packets/COMPONENT-170_RUVECTOR_MEMBER_RVAGENT_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-171_RUVECTOR_MEMBER_RVAGENT_ACP",
    "packet": "generated/execution_packets/COMPONENT-171_RUVECTOR_MEMBER_RVAGENT_ACP.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-172_RUVECTOR_MEMBER_RVAGENT_MCP",
    "packet": "generated/execution_packets/COMPONENT-172_RUVECTOR_MEMBER_RVAGENT_MCP.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-173_RUVECTOR_MEMBER_RVAGENT_WASM",
    "packet": "generated/execution_packets/COMPONENT-173_RUVECTOR_MEMBER_RVAGENT_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-174_RUVECTOR_MEMBER_RVAGENT_A2A",
    "packet": "generated/execution_packets/COMPONENT-174_RUVECTOR_MEMBER_RVAGENT_A2A.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-175_RUVECTOR_MEMBER_A2A_SWARM",
    "packet": "generated/execution_packets/COMPONENT-175_RUVECTOR_MEMBER_A2A_SWARM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-176_RUVECTOR_MEMBER_TRAIN_DISCOVERIES",
    "packet": "generated/execution_packets/COMPONENT-176_RUVECTOR_MEMBER_TRAIN_DISCOVERIES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-177_RUVECTOR_MEMBER_SKY_MONITOR",
    "packet": "generated/execution_packets/COMPONENT-177_RUVECTOR_MEMBER_SKY_MONITOR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-178_RUVECTOR_MEMBER_WASM",
    "packet": "generated/execution_packets/COMPONENT-178_RUVECTOR_MEMBER_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-179_RUVECTOR_MEMBER_RUVECTOR_SPARSIFIER",
    "packet": "generated/execution_packets/COMPONENT-179_RUVECTOR_MEMBER_RUVECTOR_SPARSIFIER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-180_RUVECTOR_MEMBER_RUVECTOR_SPARSIFIER_WASM",
    "packet": "generated/execution_packets/COMPONENT-180_RUVECTOR_MEMBER_RUVECTOR_SPARSIFIER_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-181_RUVECTOR_MEMBER_RUVECTOR_CONSCIOUSNESS",
    "packet": "generated/execution_packets/COMPONENT-181_RUVECTOR_MEMBER_RUVECTOR_CONSCIOUSNESS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-182_RUVECTOR_MEMBER_RUVECTOR_CONSCIOUSNESS_WASM",
    "packet": "generated/execution_packets/COMPONENT-182_RUVECTOR_MEMBER_RUVECTOR_CONSCIOUSNESS_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-183_RUVECTOR_MEMBER_CMB_CONSCIOUSNESS",
    "packet": "generated/execution_packets/COMPONENT-183_RUVECTOR_MEMBER_CMB_CONSCIOUSNESS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-184_RUVECTOR_MEMBER_GW_CONSCIOUSNESS",
    "packet": "generated/execution_packets/COMPONENT-184_RUVECTOR_MEMBER_GW_CONSCIOUSNESS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-185_RUVECTOR_MEMBER_ECOSYSTEM_CONSCIOUSNESS",
    "packet": "generated/execution_packets/COMPONENT-185_RUVECTOR_MEMBER_ECOSYSTEM_CONSCIOUSNESS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-186_RUVECTOR_MEMBER_QUANTUM_CONSCIOUSNESS",
    "packet": "generated/execution_packets/COMPONENT-186_RUVECTOR_MEMBER_QUANTUM_CONSCIOUSNESS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-187_RUVECTOR_MEMBER_GENE_CONSCIOUSNESS",
    "packet": "generated/execution_packets/COMPONENT-187_RUVECTOR_MEMBER_GENE_CONSCIOUSNESS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-188_RUVECTOR_MEMBER_CLIMATE_CONSCIOUSNESS",
    "packet": "generated/execution_packets/COMPONENT-188_RUVECTOR_MEMBER_CLIMATE_CONSCIOUSNESS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-189_RUVECTOR_MEMBER_RUVECTOR_DECOMPILER",
    "packet": "generated/execution_packets/COMPONENT-189_RUVECTOR_MEMBER_RUVECTOR_DECOMPILER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-190_RUVECTOR_MEMBER_RUVECTOR_DECOMPILER_WASM",
    "packet": "generated/execution_packets/COMPONENT-190_RUVECTOR_MEMBER_RUVECTOR_DECOMPILER_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-191_RUVECTOR_MEMBER_RUVECTOR_DISKANN",
    "packet": "generated/execution_packets/COMPONENT-191_RUVECTOR_MEMBER_RUVECTOR_DISKANN.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-192_RUVECTOR_MEMBER_RUVECTOR_DISKANN_NODE",
    "packet": "generated/execution_packets/COMPONENT-192_RUVECTOR_MEMBER_RUVECTOR_DISKANN_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-193_RUVECTOR_MEMBER_BOUNDARY_DISCOVERY",
    "packet": "generated/execution_packets/COMPONENT-193_RUVECTOR_MEMBER_BOUNDARY_DISCOVERY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-194_RUVECTOR_MEMBER_CMB_BOUNDARY_DISCOVERY",
    "packet": "generated/execution_packets/COMPONENT-194_RUVECTOR_MEMBER_CMB_BOUNDARY_DISCOVERY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-195_RUVECTOR_MEMBER_FRB_BOUNDARY_DISCOVERY",
    "packet": "generated/execution_packets/COMPONENT-195_RUVECTOR_MEMBER_FRB_BOUNDARY_DISCOVERY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-196_RUVECTOR_MEMBER_VOID_BOUNDARY_DISCOVERY",
    "packet": "generated/execution_packets/COMPONENT-196_RUVECTOR_MEMBER_VOID_BOUNDARY_DISCOVERY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-197_RUVECTOR_MEMBER_TEMPORAL_ATTRACTOR_DISCOVERY",
    "packet": "generated/execution_packets/COMPONENT-197_RUVECTOR_MEMBER_TEMPORAL_ATTRACTOR_DISCOVERY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-198_RUVECTOR_MEMBER_MUSIC_BOUNDARY_DISCOVERY",
    "packet": "generated/execution_packets/COMPONENT-198_RUVECTOR_MEMBER_MUSIC_BOUNDARY_DISCOVERY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-199_RUVECTOR_MEMBER_WEATHER_BOUNDARY_DISCOVERY",
    "packet": "generated/execution_packets/COMPONENT-199_RUVECTOR_MEMBER_WEATHER_BOUNDARY_DISCOVERY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-200_RUVECTOR_MEMBER_MARKET_BOUNDARY_DISCOVERY",
    "packet": "generated/execution_packets/COMPONENT-200_RUVECTOR_MEMBER_MARKET_BOUNDARY_DISCOVERY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-201_RUVECTOR_MEMBER_HEALTH_BOUNDARY_DISCOVERY",
    "packet": "generated/execution_packets/COMPONENT-201_RUVECTOR_MEMBER_HEALTH_BOUNDARY_DISCOVERY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-202_RUVECTOR_MEMBER_SETI_EXOTIC_SIGNALS",
    "packet": "generated/execution_packets/COMPONENT-202_RUVECTOR_MEMBER_SETI_EXOTIC_SIGNALS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-203_RUVECTOR_MEMBER_SETI_BOUNDARY_DISCOVERY",
    "packet": "generated/execution_packets/COMPONENT-203_RUVECTOR_MEMBER_SETI_BOUNDARY_DISCOVERY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-204_RUVECTOR_MEMBER_EARTHQUAKE_BOUNDARY_DISCOVER",
    "packet": "generated/execution_packets/COMPONENT-204_RUVECTOR_MEMBER_EARTHQUAKE_BOUNDARY_DISCOVER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-205_RUVECTOR_MEMBER_PANDEMIC_BOUNDARY_DISCOVERY",
    "packet": "generated/execution_packets/COMPONENT-205_RUVECTOR_MEMBER_PANDEMIC_BOUNDARY_DISCOVERY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-206_RUVECTOR_MEMBER_INFRASTRUCTURE_BOUNDARY_DISC",
    "packet": "generated/execution_packets/COMPONENT-206_RUVECTOR_MEMBER_INFRASTRUCTURE_BOUNDARY_DISC.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-207_RUVECTOR_MEMBER_BRAIN_BOUNDARY_DISCOVERY",
    "packet": "generated/execution_packets/COMPONENT-207_RUVECTOR_MEMBER_BRAIN_BOUNDARY_DISCOVERY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-208_RUVECTOR_MEMBER_SEIZURE_CLINICAL_REPORT",
    "packet": "generated/execution_packets/COMPONENT-208_RUVECTOR_MEMBER_SEIZURE_CLINICAL_REPORT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-209_RUVECTOR_MEMBER_SEIZURE_THERAPEUTIC_SIM",
    "packet": "generated/execution_packets/COMPONENT-209_RUVECTOR_MEMBER_SEIZURE_THERAPEUTIC_SIM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-210_RUVECTOR_MEMBER_REAL_EEG_ANALYSIS",
    "packet": "generated/execution_packets/COMPONENT-210_RUVECTOR_MEMBER_REAL_EEG_ANALYSIS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-211_RUVECTOR_MEMBER_REAL_EEG_MULTI_SEIZURE",
    "packet": "generated/execution_packets/COMPONENT-211_RUVECTOR_MEMBER_REAL_EEG_MULTI_SEIZURE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-212_RUVECTOR_MEMBER_RUVLLM_SPARSE_ATTENTION",
    "packet": "generated/execution_packets/COMPONENT-212_RUVECTOR_MEMBER_RUVLLM_SPARSE_ATTENTION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-213_RUVECTOR_MEMBER_RUVLLM_RETRIEVAL_DIFFUSION",
    "packet": "generated/execution_packets/COMPONENT-213_RUVECTOR_MEMBER_RUVLLM_RETRIEVAL_DIFFUSION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-214_RUVECTOR_MEMBER_RUVECTOR_RAIRS",
    "packet": "generated/execution_packets/COMPONENT-214_RUVECTOR_MEMBER_RUVECTOR_RAIRS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-215_RUVECTOR_MEMBER_RUVECTOR_HYBRID",
    "packet": "generated/execution_packets/COMPONENT-215_RUVECTOR_MEMBER_RUVECTOR_HYBRID.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-216_RUVECTOR_MEMBER_RUVECTOR_LSM_ANN",
    "packet": "generated/execution_packets/COMPONENT-216_RUVECTOR_MEMBER_RUVECTOR_LSM_ANN.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-217_RUVECTOR_MEMBER_RUVECTOR_GRAPH_CONDENSE",
    "packet": "generated/execution_packets/COMPONENT-217_RUVECTOR_MEMBER_RUVECTOR_GRAPH_CONDENSE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-218_RUVECTOR_MEMBER_RUVECTOR_GRAPH_CONDENSE_WASM",
    "packet": "generated/execution_packets/COMPONENT-218_RUVECTOR_MEMBER_RUVECTOR_GRAPH_CONDENSE_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-219_RUVECTOR_MEMBER_RUVECTOR_PERCEPTION",
    "packet": "generated/execution_packets/COMPONENT-219_RUVECTOR_MEMBER_RUVECTOR_PERCEPTION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-220_RUVECTOR_MEMBER_EMERGENT_TIME",
    "packet": "generated/execution_packets/COMPONENT-220_RUVECTOR_MEMBER_EMERGENT_TIME.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-221_RUVECTOR_MEMBER_PHOTONLAYER_CORE",
    "packet": "generated/execution_packets/COMPONENT-221_RUVECTOR_MEMBER_PHOTONLAYER_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-222_RUVECTOR_MEMBER_PHOTONLAYER_BENCH",
    "packet": "generated/execution_packets/COMPONENT-222_RUVECTOR_MEMBER_PHOTONLAYER_BENCH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-223_RUVECTOR_MEMBER_PHOTONLAYER_RUVECTOR",
    "packet": "generated/execution_packets/COMPONENT-223_RUVECTOR_MEMBER_PHOTONLAYER_RUVECTOR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-224_RUVECTOR_MEMBER_PHOTONLAYER_CLI",
    "packet": "generated/execution_packets/COMPONENT-224_RUVECTOR_MEMBER_PHOTONLAYER_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-225_RUVECTOR_MEMBER_PHOTONLAYER_WASM",
    "packet": "generated/execution_packets/COMPONENT-225_RUVECTOR_MEMBER_PHOTONLAYER_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-226_RUVECTOR_MEMBER_RUVECTOR_MATRYOSHKA",
    "packet": "generated/execution_packets/COMPONENT-226_RUVECTOR_MEMBER_RUVECTOR_MATRYOSHKA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-227_RUVECTOR_MEMBER_RUVECTOR_PQ_SEARCH",
    "packet": "generated/execution_packets/COMPONENT-227_RUVECTOR_MEMBER_RUVECTOR_PQ_SEARCH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-228_RUVECTOR_MEMBER_RUVECTOR_SOTA_BENCH",
    "packet": "generated/execution_packets/COMPONENT-228_RUVECTOR_MEMBER_RUVECTOR_SOTA_BENCH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-229_RUVECTOR_MEMBER_RUVECTOR_CAPGATED",
    "packet": "generated/execution_packets/COMPONENT-229_RUVECTOR_MEMBER_RUVECTOR_CAPGATED.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-230_RUVECTOR_MEMBER_RUVECTOR_SPANN",
    "packet": "generated/execution_packets/COMPONENT-230_RUVECTOR_MEMBER_RUVECTOR_SPANN.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-231_RUVECTOR_MEMBER_RUVECTOR_MAXSIM",
    "packet": "generated/execution_packets/COMPONENT-231_RUVECTOR_MEMBER_RUVECTOR_MAXSIM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-232_RUVECTOR_MEMBER_TIMESFM",
    "packet": "generated/execution_packets/COMPONENT-232_RUVECTOR_MEMBER_TIMESFM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-233_RUVECTOR_MEMBER_RUVECTOR_TIMESFM",
    "packet": "generated/execution_packets/COMPONENT-233_RUVECTOR_MEMBER_RUVECTOR_TIMESFM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-234_RVF_TYPES",
    "packet": "generated/execution_packets/COMPONENT-234_RVF_TYPES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-235_RVF_WIRE",
    "packet": "generated/execution_packets/COMPONENT-235_RVF_WIRE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-236_RVF_MANIFEST",
    "packet": "generated/execution_packets/COMPONENT-236_RVF_MANIFEST.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-237_RVF_INDEX",
    "packet": "generated/execution_packets/COMPONENT-237_RVF_INDEX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-238_RVF_QUANT",
    "packet": "generated/execution_packets/COMPONENT-238_RVF_QUANT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-239_RVF_CRYPTO",
    "packet": "generated/execution_packets/COMPONENT-239_RVF_CRYPTO.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-240_RVF_RUNTIME",
    "packet": "generated/execution_packets/COMPONENT-240_RVF_RUNTIME.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-241_RVF_KERNEL",
    "packet": "generated/execution_packets/COMPONENT-241_RVF_KERNEL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-242_RVF_WASM",
    "packet": "generated/execution_packets/COMPONENT-242_RVF_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-243_RVF_SOLVER_WASM",
    "packet": "generated/execution_packets/COMPONENT-243_RVF_SOLVER_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-244_RVF_NODE",
    "packet": "generated/execution_packets/COMPONENT-244_RVF_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-245_RVF_SERVER",
    "packet": "generated/execution_packets/COMPONENT-245_RVF_SERVER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-246_RVF_IMPORT",
    "packet": "generated/execution_packets/COMPONENT-246_RVF_IMPORT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-247_RVF_ADAPTER_CLAUDE_FLOW",
    "packet": "generated/execution_packets/COMPONENT-247_RVF_ADAPTER_CLAUDE_FLOW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-248_RVF_ADAPTER_AGENTDB",
    "packet": "generated/execution_packets/COMPONENT-248_RVF_ADAPTER_AGENTDB.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-249_RVF_ADAPTER_OSPIPE",
    "packet": "generated/execution_packets/COMPONENT-249_RVF_ADAPTER_OSPIPE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-250_RVF_ADAPTER_AGENTIC_FLOW",
    "packet": "generated/execution_packets/COMPONENT-250_RVF_ADAPTER_AGENTIC_FLOW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-251_RVF_ADAPTER_RVLITE",
    "packet": "generated/execution_packets/COMPONENT-251_RVF_ADAPTER_RVLITE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-252_RVF_ADAPTER_SONA",
    "packet": "generated/execution_packets/COMPONENT-252_RVF_ADAPTER_SONA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-253_RVF_LAUNCH",
    "packet": "generated/execution_packets/COMPONENT-253_RVF_LAUNCH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-254_RVF_EBPF",
    "packet": "generated/execution_packets/COMPONENT-254_RVF_EBPF.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-255_RVF_CLI",
    "packet": "generated/execution_packets/COMPONENT-255_RVF_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-256_RVF_INTEGRATION_TESTS",
    "packet": "generated/execution_packets/COMPONENT-256_RVF_INTEGRATION_TESTS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-257_RVF_BENCHES",
    "packet": "generated/execution_packets/COMPONENT-257_RVF_BENCHES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-258_RVF_FEDERATION",
    "packet": "generated/execution_packets/COMPONENT-258_RVF_FEDERATION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-259_RUVECTOR_DETACHED_OSPIPE",
    "packet": "generated/execution_packets/COMPONENT-259_RUVECTOR_DETACHED_OSPIPE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-260_RUVECTOR_DETACHED_RVF_EXAMPLES",
    "packet": "generated/execution_packets/COMPONENT-260_RUVECTOR_DETACHED_RVF_EXAMPLES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-261_RUVECTOR_DETACHED_MICRO_HNSW_WASM",
    "packet": "generated/execution_packets/COMPONENT-261_RUVECTOR_DETACHED_MICRO_HNSW_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-262_RUVECTOR_DETACHED_RUVECTOR_HYPERBOLIC_HNSW",
    "packet": "generated/execution_packets/COMPONENT-262_RUVECTOR_DETACHED_RUVECTOR_HYPERBOLIC_HNSW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-263_RUVECTOR_DETACHED_RUVECTOR_HYPERBOLIC_HNSW_W",
    "packet": "generated/execution_packets/COMPONENT-263_RUVECTOR_DETACHED_RUVECTOR_HYPERBOLIC_HNSW_W.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-264_RUVECTOR_DETACHED_RUVLLM_ESP32",
    "packet": "generated/execution_packets/COMPONENT-264_RUVECTOR_DETACHED_RUVLLM_ESP32.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-265_RUVECTOR_DETACHED_RUVLLM_ESP32_FLASH",
    "packet": "generated/execution_packets/COMPONENT-265_RUVECTOR_DETACHED_RUVLLM_ESP32_FLASH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-266_RUVECTOR_DETACHED_RUVECTOR_EDGE_NET",
    "packet": "generated/execution_packets/COMPONENT-266_RUVECTOR_DETACHED_RUVECTOR_EDGE_NET.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-267_RUVECTOR_DETACHED_RUVECTOR_DATA_FRAMEWORK",
    "packet": "generated/execution_packets/COMPONENT-267_RUVECTOR_DETACHED_RUVECTOR_DATA_FRAMEWORK.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-268_RUVECTOR_DETACHED_RUVECTOR_DATA_OPENALEX",
    "packet": "generated/execution_packets/COMPONENT-268_RUVECTOR_DETACHED_RUVECTOR_DATA_OPENALEX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-269_RUVECTOR_DETACHED_RUVECTOR_DATA_CLIMATE",
    "packet": "generated/execution_packets/COMPONENT-269_RUVECTOR_DETACHED_RUVECTOR_DATA_CLIMATE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-270_RUVECTOR_DETACHED_RUVECTOR_DATA_EDGAR",
    "packet": "generated/execution_packets/COMPONENT-270_RUVECTOR_DETACHED_RUVECTOR_DATA_EDGAR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-271_RUVECTOR_DETACHED_RUVLLM_EXAMPLES",
    "packet": "generated/execution_packets/COMPONENT-271_RUVECTOR_DETACHED_RUVLLM_EXAMPLES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-272_RUVECTOR_DETACHED_DELTA_BEHAVIOR",
    "packet": "generated/execution_packets/COMPONENT-272_RUVECTOR_DETACHED_DELTA_BEHAVIOR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-273_RUVECTOR_DETACHED_RVF_DESKTOP",
    "packet": "generated/execution_packets/COMPONENT-273_RUVECTOR_DETACHED_RVF_DESKTOP.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-274_RUVECTOR_DETACHED_EMERGENT_TIME_WASM",
    "packet": "generated/execution_packets/COMPONENT-274_RUVECTOR_DETACHED_EMERGENT_TIME_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-275_RUVECTOR_DETACHED_SONIC_CT",
    "packet": "generated/execution_packets/COMPONENT-275_RUVECTOR_DETACHED_SONIC_CT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-276_RUVECTOR_DETACHED_SONIC_CT_WASM",
    "packet": "generated/execution_packets/COMPONENT-276_RUVECTOR_DETACHED_SONIC_CT_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-277_RUVECTOR_DETACHED_RUVECTOR_POSTGRES_DETACHED",
    "packet": "generated/execution_packets/COMPONENT-277_RUVECTOR_DETACHED_RUVECTOR_POSTGRES_DETACHED.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-278_RUVECTOR_DETACHED_RUOS_THERMAL",
    "packet": "generated/execution_packets/COMPONENT-278_RUVECTOR_DETACHED_RUOS_THERMAL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-279_RUVECTOR_DETACHED_EXTERNAL_RUQU",
    "packet": "generated/execution_packets/COMPONENT-279_RUVECTOR_DETACHED_EXTERNAL_RUQU.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-280_RUVECTOR_DETACHED_EXTERNAL_RVDNA",
    "packet": "generated/execution_packets/COMPONENT-280_RUVECTOR_DETACHED_EXTERNAL_RVDNA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-281_RUVECTOR",
    "packet": "generated/execution_packets/COMPONENT-281_RUVECTOR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-282_RUVECTOR_CORE",
    "packet": "generated/execution_packets/COMPONENT-282_RUVECTOR_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-283_RUVECTOR_CORE_NATIVE_PLATFORMS",
    "packet": "generated/execution_packets/COMPONENT-283_RUVECTOR_CORE_NATIVE_PLATFORMS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-284_RUVECTOR_WASM",
    "packet": "generated/execution_packets/COMPONENT-284_RUVECTOR_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-285_RUVECTOR_ROUTER",
    "packet": "generated/execution_packets/COMPONENT-285_RUVECTOR_ROUTER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-286_RUVECTOR_GNN",
    "packet": "generated/execution_packets/COMPONENT-286_RUVECTOR_GNN.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-287_RUVECTOR_ATTENTION",
    "packet": "generated/execution_packets/COMPONENT-287_RUVECTOR_ATTENTION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-288_RUVECTOR_ATTENTION_WASM",
    "packet": "generated/execution_packets/COMPONENT-288_RUVECTOR_ATTENTION_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-289_RUVECTOR_RUVLLM",
    "packet": "generated/execution_packets/COMPONENT-289_RUVECTOR_RUVLLM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-290_RUVECTOR_RUVLLM_NATIVE_PLATFORMS",
    "packet": "generated/execution_packets/COMPONENT-290_RUVECTOR_RUVLLM_NATIVE_PLATFORMS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-291_RUVECTOR_RUVLLM_WASM",
    "packet": "generated/execution_packets/COMPONENT-291_RUVECTOR_RUVLLM_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-292_RUVECTOR_SONA",
    "packet": "generated/execution_packets/COMPONENT-292_RUVECTOR_SONA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-293_RUVECTOR_SONA_NATIVE_PLATFORMS",
    "packet": "generated/execution_packets/COMPONENT-293_RUVECTOR_SONA_NATIVE_PLATFORMS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-294_RUVECTOR_RVF",
    "packet": "generated/execution_packets/COMPONENT-294_RUVECTOR_RVF.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-295_RUVECTOR_POSTGRES_CLI",
    "packet": "generated/execution_packets/COMPONENT-295_RUVECTOR_POSTGRES_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-296_LIFEOS_COMPONENT_SRC_TAURI",
    "packet": "generated/execution_packets/COMPONENT-296_LIFEOS_COMPONENT_SRC_TAURI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-297_LIFEOS_COMPONENT_LIFEOS_CORE",
    "packet": "generated/execution_packets/COMPONENT-297_LIFEOS_COMPONENT_LIFEOS_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-298_LIFEOS_COMPONENT_LIFEOS_DAEMON",
    "packet": "generated/execution_packets/COMPONENT-298_LIFEOS_COMPONENT_LIFEOS_DAEMON.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-299_LIFEOS_COMPONENT_LIFEOS_VUE",
    "packet": "generated/execution_packets/COMPONENT-299_LIFEOS_COMPONENT_LIFEOS_VUE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-300_ENVCTL_COMPONENT_AGENT_ENV",
    "packet": "generated/execution_packets/COMPONENT-300_ENVCTL_COMPONENT_AGENT_ENV.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-301_ENVCTL_COMPONENT_ENGINE",
    "packet": "generated/execution_packets/COMPONENT-301_ENVCTL_COMPONENT_ENGINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-302_ENVCTL_COMPONENT_CLI",
    "packet": "generated/execution_packets/COMPONENT-302_ENVCTL_COMPONENT_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-303_ENVCTL_COMPONENT_GUI",
    "packet": "generated/execution_packets/COMPONENT-303_ENVCTL_COMPONENT_GUI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-304_ENVCTL_COMPONENT_SECRETS_ENGINE",
    "packet": "generated/execution_packets/COMPONENT-304_ENVCTL_COMPONENT_SECRETS_ENGINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-305_ENVCTL_COMPONENT_SECRETS_PROTO",
    "packet": "generated/execution_packets/COMPONENT-305_ENVCTL_COMPONENT_SECRETS_PROTO.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-306_ENVCTL_COMPONENT_SECRETD",
    "packet": "generated/execution_packets/COMPONENT-306_ENVCTL_COMPONENT_SECRETD.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-307_ENVCTL_COMPONENT_SECRETCTL",
    "packet": "generated/execution_packets/COMPONENT-307_ENVCTL_COMPONENT_SECRETCTL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-308_ENVCTL_COMPONENT_SECRETS_STORE_LIBSQL",
    "packet": "generated/execution_packets/COMPONENT-308_ENVCTL_COMPONENT_SECRETS_STORE_LIBSQL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-309_WEAVE_COMPONENT_WEAVE_CORE",
    "packet": "generated/execution_packets/COMPONENT-309_WEAVE_COMPONENT_WEAVE_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-310_WEAVE_COMPONENT_WEAVE_INJECT",
    "packet": "generated/execution_packets/COMPONENT-310_WEAVE_COMPONENT_WEAVE_INJECT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-311_WEAVE_COMPONENT_WEAVE_MCP",
    "packet": "generated/execution_packets/COMPONENT-311_WEAVE_COMPONENT_WEAVE_MCP.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-312_WEAVE_COMPONENT_WEAVE",
    "packet": "generated/execution_packets/COMPONENT-312_WEAVE_COMPONENT_WEAVE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-313_NETWORK_CONTROL_COMPONENT_NETENGINE",
    "packet": "generated/execution_packets/COMPONENT-313_NETWORK_CONTROL_COMPONENT_NETENGINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-314_NETWORK_CONTROL_COMPONENT_NETCTL",
    "packet": "generated/execution_packets/COMPONENT-314_NETWORK_CONTROL_COMPONENT_NETCTL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-315_NETWORK_CONTROL_COMPONENT_NETCTL_GUI",
    "packet": "generated/execution_packets/COMPONENT-315_NETWORK_CONTROL_COMPONENT_NETCTL_GUI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-316_FLEXNETOS_RUNNER_COMPONENT_RUNNER_CORE",
    "packet": "generated/execution_packets/COMPONENT-316_FLEXNETOS_RUNNER_COMPONENT_RUNNER_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-317_FLEXNETOS_RUNNER_COMPONENT_RUNNER_ACTIONS",
    "packet": "generated/execution_packets/COMPONENT-317_FLEXNETOS_RUNNER_COMPONENT_RUNNER_ACTIONS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-318_FLEXNETOS_RUNNER_COMPONENT_RUNNER_DISPATCH",
    "packet": "generated/execution_packets/COMPONENT-318_FLEXNETOS_RUNNER_COMPONENT_RUNNER_DISPATCH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-319_FLEXNETOS_RUNNER_COMPONENT_RUNNER_CLI",
    "packet": "generated/execution_packets/COMPONENT-319_FLEXNETOS_RUNNER_COMPONENT_RUNNER_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-320_RUSTY_IDD_COMPONENT_WORK_ORDER",
    "packet": "generated/execution_packets/COMPONENT-320_RUSTY_IDD_COMPONENT_WORK_ORDER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-321_RUSTY_IDD_COMPONENT_LEDGER",
    "packet": "generated/execution_packets/COMPONENT-321_RUSTY_IDD_COMPONENT_LEDGER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-322_RUSTY_IDD_COMPONENT_HANDOFF_CORE",
    "packet": "generated/execution_packets/COMPONENT-322_RUSTY_IDD_COMPONENT_HANDOFF_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-323_RUSTY_IDD_COMPONENT_HANDOFF_POLICY",
    "packet": "generated/execution_packets/COMPONENT-323_RUSTY_IDD_COMPONENT_HANDOFF_POLICY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-324_RUSTY_IDD_COMPONENT_HANDOFF_SCHEMA",
    "packet": "generated/execution_packets/COMPONENT-324_RUSTY_IDD_COMPONENT_HANDOFF_SCHEMA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-325_RUSTY_IDD_COMPONENT_HANDOFF_LEASE",
    "packet": "generated/execution_packets/COMPONENT-325_RUSTY_IDD_COMPONENT_HANDOFF_LEASE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-326_RUSTY_IDD_COMPONENT_HANDOFF_HOOKS",
    "packet": "generated/execution_packets/COMPONENT-326_RUSTY_IDD_COMPONENT_HANDOFF_HOOKS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-327_RUSTY_IDD_COMPONENT_HANDOFF_INDEX",
    "packet": "generated/execution_packets/COMPONENT-327_RUSTY_IDD_COMPONENT_HANDOFF_INDEX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-328_RUSTY_IDD_COMPONENT_HANDOFF_FLEET",
    "packet": "generated/execution_packets/COMPONENT-328_RUSTY_IDD_COMPONENT_HANDOFF_FLEET.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-329_RUSTY_IDD_COMPONENT_HANDOFF_DRIFT",
    "packet": "generated/execution_packets/COMPONENT-329_RUSTY_IDD_COMPONENT_HANDOFF_DRIFT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-330_RUSTY_IDD_COMPONENT_HANDOFF_ROUTE",
    "packet": "generated/execution_packets/COMPONENT-330_RUSTY_IDD_COMPONENT_HANDOFF_ROUTE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-331_RUSTY_IDD_COMPONENT_HANDOFF_TEST_SUPPORT",
    "packet": "generated/execution_packets/COMPONENT-331_RUSTY_IDD_COMPONENT_HANDOFF_TEST_SUPPORT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-332_RUSTY_IDD_COMPONENT_HANDOFF_SECRETS",
    "packet": "generated/execution_packets/COMPONENT-332_RUSTY_IDD_COMPONENT_HANDOFF_SECRETS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-333_RUSTY_IDD_COMPONENT_HANDOFF_GATEKEEPER",
    "packet": "generated/execution_packets/COMPONENT-333_RUSTY_IDD_COMPONENT_HANDOFF_GATEKEEPER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-334_RUSTY_IDD_COMPONENT_HANDOFF_INTAKE",
    "packet": "generated/execution_packets/COMPONENT-334_RUSTY_IDD_COMPONENT_HANDOFF_INTAKE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-335_RUSTY_IDD_COMPONENT_HF",
    "packet": "generated/execution_packets/COMPONENT-335_RUSTY_IDD_COMPONENT_HF.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-336_RUSTY_IDD_COMPONENT_CRATES_CLI",
    "packet": "generated/execution_packets/COMPONENT-336_RUSTY_IDD_COMPONENT_CRATES_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-337_RUSTY_IDD_COMPONENT_CRATES_CORE",
    "packet": "generated/execution_packets/COMPONENT-337_RUSTY_IDD_COMPONENT_CRATES_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-338_RUSTY_IDD_COMPONENT_CRATES_RUNNER",
    "packet": "generated/execution_packets/COMPONENT-338_RUSTY_IDD_COMPONENT_CRATES_RUNNER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-339_RUSTY_IDD_COMPONENT_CRATES_SPEC",
    "packet": "generated/execution_packets/COMPONENT-339_RUSTY_IDD_COMPONENT_CRATES_SPEC.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-340_RUSTY_IDD_COMPONENT_CRATES_TUI",
    "packet": "generated/execution_packets/COMPONENT-340_RUSTY_IDD_COMPONENT_CRATES_TUI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-341_RUSTY_IDD_COMPONENT_CODEGRAPH_CORE",
    "packet": "generated/execution_packets/COMPONENT-341_RUSTY_IDD_COMPONENT_CODEGRAPH_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-342_RUSTY_IDD_COMPONENT_CODEGRAPH_PARSER",
    "packet": "generated/execution_packets/COMPONENT-342_RUSTY_IDD_COMPONENT_CODEGRAPH_PARSER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-343_RUSTY_IDD_COMPONENT_REPOMIX_SHARED",
    "packet": "generated/execution_packets/COMPONENT-343_RUSTY_IDD_COMPONENT_REPOMIX_SHARED.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-344_RUSTY_IDD_COMPONENT_KNOWLEDGE",
    "packet": "generated/execution_packets/COMPONENT-344_RUSTY_IDD_COMPONENT_KNOWLEDGE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-345_RUSTY_IDD_COMPONENT_MERGE_TOOLS",
    "packet": "generated/execution_packets/COMPONENT-345_RUSTY_IDD_COMPONENT_MERGE_TOOLS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-346_NU_PLUGIN_COMPONENT_CODEDB",
    "packet": "generated/execution_packets/COMPONENT-346_NU_PLUGIN_COMPONENT_CODEDB.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-347_NU_PLUGIN_COMPONENT_CODEDB_CARGO",
    "packet": "generated/execution_packets/COMPONENT-347_NU_PLUGIN_COMPONENT_CODEDB_CARGO.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-348_NU_PLUGIN_COMPONENT_CODEDB_CONTEXT",
    "packet": "generated/execution_packets/COMPONENT-348_NU_PLUGIN_COMPONENT_CODEDB_CONTEXT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-349_NU_PLUGIN_COMPONENT_CODEDB_CORE",
    "packet": "generated/execution_packets/COMPONENT-349_NU_PLUGIN_COMPONENT_CODEDB_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-350_NU_PLUGIN_COMPONENT_CODEDB_FIXTURES",
    "packet": "generated/execution_packets/COMPONENT-350_NU_PLUGIN_COMPONENT_CODEDB_FIXTURES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-351_NU_PLUGIN_COMPONENT_CODEDB_BUILD_CAPTURE",
    "packet": "generated/execution_packets/COMPONENT-351_NU_PLUGIN_COMPONENT_CODEDB_BUILD_CAPTURE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-352_NU_PLUGIN_COMPONENT_CODEDB_MCP",
    "packet": "generated/execution_packets/COMPONENT-352_NU_PLUGIN_COMPONENT_CODEDB_MCP.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-353_NU_PLUGIN_COMPONENT_CODEDB_RUST_STATIC",
    "packet": "generated/execution_packets/COMPONENT-353_NU_PLUGIN_COMPONENT_CODEDB_RUST_STATIC.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-354_NU_PLUGIN_COMPONENT_CODEDB_STORE_REDB",
    "packet": "generated/execution_packets/COMPONENT-354_NU_PLUGIN_COMPONENT_CODEDB_STORE_REDB.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-355_NU_PLUGIN_COMPONENT_CODEDB_STORE_PG",
    "packet": "generated/execution_packets/COMPONENT-355_NU_PLUGIN_COMPONENT_CODEDB_STORE_PG.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-356_NU_PLUGIN_COMPONENT_NU_PLUGIN_CODEDB",
    "packet": "generated/execution_packets/COMPONENT-356_NU_PLUGIN_COMPONENT_NU_PLUGIN_CODEDB.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-357_ICM_COMPONENT_ICM_CORE",
    "packet": "generated/execution_packets/COMPONENT-357_ICM_COMPONENT_ICM_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-358_ICM_COMPONENT_ICM_STORE",
    "packet": "generated/execution_packets/COMPONENT-358_ICM_COMPONENT_ICM_STORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-359_ICM_COMPONENT_ICM_MCP",
    "packet": "generated/execution_packets/COMPONENT-359_ICM_COMPONENT_ICM_MCP.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-360_ICM_COMPONENT_ICM_CLI",
    "packet": "generated/execution_packets/COMPONENT-360_ICM_COMPONENT_ICM_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-361_META",
    "packet": "generated/execution_packets/COMPONENT-361_META.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-362_GITKB",
    "packet": "generated/execution_packets/COMPONENT-362_GITKB.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-363_BEADS_RUST_BR",
    "packet": "generated/execution_packets/COMPONENT-363_BEADS_RUST_BR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-364_YAZELIX",
    "packet": "generated/execution_packets/COMPONENT-364_YAZELIX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-365_YAZELIX_TERMINAL_SUPPORT",
    "packet": "generated/execution_packets/COMPONENT-365_YAZELIX_TERMINAL_SUPPORT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-366_RTK_NU",
    "packet": "generated/execution_packets/COMPONENT-366_RTK_NU.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-367_RUVLTRA",
    "packet": "generated/execution_packets/COMPONENT-367_RUVLTRA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-368_MICROLORA",
    "packet": "generated/execution_packets/COMPONENT-368_MICROLORA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-369_ATAS",
    "packet": "generated/execution_packets/COMPONENT-369_ATAS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-370_CLAUDE_FLOW",
    "packet": "generated/execution_packets/COMPONENT-370_CLAUDE_FLOW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-371_CLAUDE_FLOW_NEURAL",
    "packet": "generated/execution_packets/COMPONENT-371_CLAUDE_FLOW_NEURAL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-372_CLAUDE_FLOW_MEMORY",
    "packet": "generated/execution_packets/COMPONENT-372_CLAUDE_FLOW_MEMORY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-373_CLAUDE_FLOW_MCP",
    "packet": "generated/execution_packets/COMPONENT-373_CLAUDE_FLOW_MCP.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-374_CLAUDE_FLOW_SHARED",
    "packet": "generated/execution_packets/COMPONENT-374_CLAUDE_FLOW_SHARED.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-375_ATC",
    "packet": "generated/execution_packets/COMPONENT-375_ATC.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-376_FLEXNETOS_AGENT",
    "packet": "generated/execution_packets/COMPONENT-376_FLEXNETOS_AGENT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-377_GIT",
    "packet": "generated/execution_packets/COMPONENT-377_GIT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-378_NIX",
    "packet": "generated/execution_packets/COMPONENT-378_NIX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-379_NUSHELL",
    "packet": "generated/execution_packets/COMPONENT-379_NUSHELL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-380_ZELLIJ",
    "packet": "generated/execution_packets/COMPONENT-380_ZELLIJ.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-381_YAZI",
    "packet": "generated/execution_packets/COMPONENT-381_YAZI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-382_HELIX",
    "packet": "generated/execution_packets/COMPONENT-382_HELIX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-383_NEOVIM",
    "packet": "generated/execution_packets/COMPONENT-383_NEOVIM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-384_CODEX",
    "packet": "generated/execution_packets/COMPONENT-384_CODEX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-385_CLAUDE",
    "packet": "generated/execution_packets/COMPONENT-385_CLAUDE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-386_BUN_BUNX",
    "packet": "generated/execution_packets/COMPONENT-386_BUN_BUNX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-387_CARGO_PGRX",
    "packet": "generated/execution_packets/COMPONENT-387_CARGO_PGRX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-388_NAPI_RS",
    "packet": "generated/execution_packets/COMPONENT-388_NAPI_RS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-389_WASM_BINDGEN_WASM_PACK",
    "packet": "generated/execution_packets/COMPONENT-389_WASM_BINDGEN_WASM_PACK.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-390_CANDLE",
    "packet": "generated/execution_packets/COMPONENT-390_CANDLE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-391_ONNX_RUNTIME_ORT",
    "packet": "generated/execution_packets/COMPONENT-391_ONNX_RUNTIME_ORT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-392_CUDA_NVIDIA",
    "packet": "generated/execution_packets/COMPONENT-392_CUDA_NVIDIA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-393_MUSL",
    "packet": "generated/execution_packets/COMPONENT-393_MUSL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-394_FENIX_KACHE_WILD",
    "packet": "generated/execution_packets/COMPONENT-394_FENIX_KACHE_WILD.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-395_LANE_OBSCURA_IROH",
    "packet": "generated/execution_packets/COMPONENT-395_LANE_OBSCURA_IROH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-396_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_BENCHMARK",
    "packet": "generated/execution_packets/COMPONENT-396_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_BENCHMARK.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-397_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_CORE",
    "packet": "generated/execution_packets/COMPONENT-397_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-398_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_EMBEDDED",
    "packet": "generated/execution_packets/COMPONENT-398_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_EMBEDDED.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-399_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_MCP",
    "packet": "generated/execution_packets/COMPONENT-399_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_MCP.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-400_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_NODE",
    "packet": "generated/execution_packets/COMPONENT-400_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-401_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_RT",
    "packet": "generated/execution_packets/COMPONENT-401_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_RT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-402_RUVECTOR_MANIFEST_EMERGENT_TIME_WASM",
    "packet": "generated/execution_packets/COMPONENT-402_RUVECTOR_MANIFEST_EMERGENT_TIME_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-403_RUVECTOR_MANIFEST_MICRO_HNSW_WASM",
    "packet": "generated/execution_packets/COMPONENT-403_RUVECTOR_MANIFEST_MICRO_HNSW_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-404_RUVECTOR_MANIFEST_RUOS_THERMAL",
    "packet": "generated/execution_packets/COMPONENT-404_RUVECTOR_MANIFEST_RUOS_THERMAL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-405_RUVECTOR_MANIFEST_RUVECTOR_AGENT_MEMORY",
    "packet": "generated/execution_packets/COMPONENT-405_RUVECTOR_MANIFEST_RUVECTOR_AGENT_MEMORY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-406_RUVECTOR_MANIFEST_RUVECTOR_ATTENTION_CLI",
    "packet": "generated/execution_packets/COMPONENT-406_RUVECTOR_MANIFEST_RUVECTOR_ATTENTION_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-407_RUVECTOR_MANIFEST_RUVECTOR_BET4_IVF_BENCH",
    "packet": "generated/execution_packets/COMPONENT-407_RUVECTOR_MANIFEST_RUVECTOR_BET4_IVF_BENCH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-408_RUVECTOR_MANIFEST_RUVECTOR_CORE_FUZZ",
    "packet": "generated/execution_packets/COMPONENT-408_RUVECTOR_MANIFEST_RUVECTOR_CORE_FUZZ.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-409_RUVECTOR_MANIFEST_RUVECTOR_GRAPH_FUZZ",
    "packet": "generated/execution_packets/COMPONENT-409_RUVECTOR_MANIFEST_RUVECTOR_GRAPH_FUZZ.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-410_RUVECTOR_MANIFEST_RUVECTOR_HNSW_REPAIR",
    "packet": "generated/execution_packets/COMPONENT-410_RUVECTOR_MANIFEST_RUVECTOR_HNSW_REPAIR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-411_RUVECTOR_MANIFEST_RUVECTOR_HYPERBOLIC_HNSW_W",
    "packet": "generated/execution_packets/COMPONENT-411_RUVECTOR_MANIFEST_RUVECTOR_HYPERBOLIC_HNSW_W.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-412_RUVECTOR_MANIFEST_RUVECTOR_HYPERBOLIC_HNSW",
    "packet": "generated/execution_packets/COMPONENT-412_RUVECTOR_MANIFEST_RUVECTOR_HYPERBOLIC_HNSW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-413_RUVECTOR_MANIFEST_RUVECTOR_MINCUT_BRAIN_NODE",
    "packet": "generated/execution_packets/COMPONENT-413_RUVECTOR_MANIFEST_RUVECTOR_MINCUT_BRAIN_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-414_RUVECTOR_MANIFEST_RUVECTOR_RAFT_FUZZ",
    "packet": "generated/execution_packets/COMPONENT-414_RUVECTOR_MANIFEST_RUVECTOR_RAFT_FUZZ.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-415_RUVECTOR_MANIFEST_RUVECTOR_SPARSE_INFERENCE_",
    "packet": "generated/execution_packets/COMPONENT-415_RUVECTOR_MANIFEST_RUVECTOR_SPARSE_INFERENCE_.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-416_RUVECTOR_MANIFEST_RUVECTOR_TEMPORAL_TENSOR_W",
    "packet": "generated/execution_packets/COMPONENT-416_RUVECTOR_MANIFEST_RUVECTOR_TEMPORAL_TENSOR_W.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-417_RUVECTOR_MANIFEST_RUVIX_BCM2711",
    "packet": "generated/execution_packets/COMPONENT-417_RUVECTOR_MANIFEST_RUVIX_BCM2711.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-418_RUVECTOR_MANIFEST_RUVIX_CLI",
    "packet": "generated/execution_packets/COMPONENT-418_RUVECTOR_MANIFEST_RUVIX_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-419_RUVECTOR_MANIFEST_RUVIX_DMA",
    "packet": "generated/execution_packets/COMPONENT-419_RUVECTOR_MANIFEST_RUVIX_DMA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-420_RUVECTOR_MANIFEST_RUVIX_DTB",
    "packet": "generated/execution_packets/COMPONENT-420_RUVECTOR_MANIFEST_RUVIX_DTB.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-421_RUVECTOR_MANIFEST_RUVIX_FS",
    "packet": "generated/execution_packets/COMPONENT-421_RUVECTOR_MANIFEST_RUVIX_FS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-422_RUVECTOR_MANIFEST_RUVIX_NET",
    "packet": "generated/execution_packets/COMPONENT-422_RUVECTOR_MANIFEST_RUVIX_NET.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-423_RUVECTOR_MANIFEST_RUVIX_PHYSMEM",
    "packet": "generated/execution_packets/COMPONENT-423_RUVECTOR_MANIFEST_RUVIX_PHYSMEM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-424_RUVECTOR_MANIFEST_RUVIX_RPI_BOOT",
    "packet": "generated/execution_packets/COMPONENT-424_RUVECTOR_MANIFEST_RUVIX_RPI_BOOT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-425_RUVECTOR_MANIFEST_RUVIX_SHELL",
    "packet": "generated/execution_packets/COMPONENT-425_RUVECTOR_MANIFEST_RUVIX_SHELL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-426_RUVECTOR_MANIFEST_RUVIX_SMP",
    "packet": "generated/execution_packets/COMPONENT-426_RUVECTOR_MANIFEST_RUVIX_SMP.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-427_RUVECTOR_MANIFEST_RVF_SWARM_DEMO",
    "packet": "generated/execution_packets/COMPONENT-427_RUVECTOR_MANIFEST_RVF_SWARM_DEMO.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-428_RUVECTOR_MANIFEST_RUVIX_QEMU_SWARM",
    "packet": "generated/execution_packets/COMPONENT-428_RUVECTOR_MANIFEST_RUVIX_QEMU_SWARM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-429_RUVECTOR_MANIFEST_RVF_BENCHES",
    "packet": "generated/execution_packets/COMPONENT-429_RUVECTOR_MANIFEST_RVF_BENCHES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-430_RUVECTOR_MANIFEST_RVF_ADAPTER_AGENTDB",
    "packet": "generated/execution_packets/COMPONENT-430_RUVECTOR_MANIFEST_RVF_ADAPTER_AGENTDB.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-431_RUVECTOR_MANIFEST_RVF_ADAPTER_AGENTIC_FLOW",
    "packet": "generated/execution_packets/COMPONENT-431_RUVECTOR_MANIFEST_RVF_ADAPTER_AGENTIC_FLOW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-432_RUVECTOR_MANIFEST_RVF_ADAPTER_CLAUDE_FLOW",
    "packet": "generated/execution_packets/COMPONENT-432_RUVECTOR_MANIFEST_RVF_ADAPTER_CLAUDE_FLOW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-433_RUVECTOR_MANIFEST_RVF_ADAPTER_OSPIPE",
    "packet": "generated/execution_packets/COMPONENT-433_RUVECTOR_MANIFEST_RVF_ADAPTER_OSPIPE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-434_RUVECTOR_MANIFEST_RVF_ADAPTER_RVLITE",
    "packet": "generated/execution_packets/COMPONENT-434_RUVECTOR_MANIFEST_RVF_ADAPTER_RVLITE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-435_RUVECTOR_MANIFEST_RVF_ADAPTER_SONA",
    "packet": "generated/execution_packets/COMPONENT-435_RUVECTOR_MANIFEST_RVF_ADAPTER_SONA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-436_RUVECTOR_MANIFEST_RVF_CLI",
    "packet": "generated/execution_packets/COMPONENT-436_RUVECTOR_MANIFEST_RVF_CLI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-437_RUVECTOR_MANIFEST_RVF_CRYPTO",
    "packet": "generated/execution_packets/COMPONENT-437_RUVECTOR_MANIFEST_RVF_CRYPTO.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-438_RUVECTOR_MANIFEST_RVF_EBPF",
    "packet": "generated/execution_packets/COMPONENT-438_RUVECTOR_MANIFEST_RVF_EBPF.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-439_RUVECTOR_MANIFEST_RVF_FEDERATION",
    "packet": "generated/execution_packets/COMPONENT-439_RUVECTOR_MANIFEST_RVF_FEDERATION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-440_RUVECTOR_MANIFEST_RVF_IMPORT",
    "packet": "generated/execution_packets/COMPONENT-440_RUVECTOR_MANIFEST_RVF_IMPORT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-441_RUVECTOR_MANIFEST_RVF_INDEX",
    "packet": "generated/execution_packets/COMPONENT-441_RUVECTOR_MANIFEST_RVF_INDEX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-442_RUVECTOR_MANIFEST_RVF_KERNEL",
    "packet": "generated/execution_packets/COMPONENT-442_RUVECTOR_MANIFEST_RVF_KERNEL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-443_RUVECTOR_MANIFEST_RVF_LAUNCH",
    "packet": "generated/execution_packets/COMPONENT-443_RUVECTOR_MANIFEST_RVF_LAUNCH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-444_RUVECTOR_MANIFEST_RVF_MANIFEST",
    "packet": "generated/execution_packets/COMPONENT-444_RUVECTOR_MANIFEST_RVF_MANIFEST.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-445_RUVECTOR_MANIFEST_RVF_NODE",
    "packet": "generated/execution_packets/COMPONENT-445_RUVECTOR_MANIFEST_RVF_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-446_RUVECTOR_MANIFEST_RVF_QUANT",
    "packet": "generated/execution_packets/COMPONENT-446_RUVECTOR_MANIFEST_RVF_QUANT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-447_RUVECTOR_MANIFEST_RVF_RUNTIME",
    "packet": "generated/execution_packets/COMPONENT-447_RUVECTOR_MANIFEST_RVF_RUNTIME.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-448_RUVECTOR_MANIFEST_RVF_SERVER",
    "packet": "generated/execution_packets/COMPONENT-448_RUVECTOR_MANIFEST_RVF_SERVER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-449_RUVECTOR_MANIFEST_RVF_SOLVER_WASM",
    "packet": "generated/execution_packets/COMPONENT-449_RUVECTOR_MANIFEST_RVF_SOLVER_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-450_RUVECTOR_MANIFEST_RVF_TYPES",
    "packet": "generated/execution_packets/COMPONENT-450_RUVECTOR_MANIFEST_RVF_TYPES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-451_RUVECTOR_MANIFEST_RVF_WASM",
    "packet": "generated/execution_packets/COMPONENT-451_RUVECTOR_MANIFEST_RVF_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-452_RUVECTOR_MANIFEST_RVF_WIRE",
    "packet": "generated/execution_packets/COMPONENT-452_RUVECTOR_MANIFEST_RVF_WIRE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-453_RUVECTOR_MANIFEST_RVF_INTEGRATION_TESTS",
    "packet": "generated/execution_packets/COMPONENT-453_RUVECTOR_MANIFEST_RVF_INTEGRATION_TESTS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-454_RUVECTOR_MANIFEST_CRATES_RVM",
    "packet": "generated/execution_packets/COMPONENT-454_RUVECTOR_MANIFEST_CRATES_RVM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-455_RUVECTOR_MANIFEST_RVM_BENCHES",
    "packet": "generated/execution_packets/COMPONENT-455_RUVECTOR_MANIFEST_RVM_BENCHES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-456_RUVECTOR_MANIFEST_RVM_BOOT",
    "packet": "generated/execution_packets/COMPONENT-456_RUVECTOR_MANIFEST_RVM_BOOT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-457_RUVECTOR_MANIFEST_RVM_CAP",
    "packet": "generated/execution_packets/COMPONENT-457_RUVECTOR_MANIFEST_RVM_CAP.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-458_RUVECTOR_MANIFEST_RVM_CHECKPOINT",
    "packet": "generated/execution_packets/COMPONENT-458_RUVECTOR_MANIFEST_RVM_CHECKPOINT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-459_RUVECTOR_MANIFEST_RVM_COHERENCE",
    "packet": "generated/execution_packets/COMPONENT-459_RUVECTOR_MANIFEST_RVM_COHERENCE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-460_RUVECTOR_MANIFEST_RVM_HAL",
    "packet": "generated/execution_packets/COMPONENT-460_RUVECTOR_MANIFEST_RVM_HAL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-461_RUVECTOR_MANIFEST_RVM_KERNEL",
    "packet": "generated/execution_packets/COMPONENT-461_RUVECTOR_MANIFEST_RVM_KERNEL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-462_RUVECTOR_MANIFEST_RVM_MEMORY",
    "packet": "generated/execution_packets/COMPONENT-462_RUVECTOR_MANIFEST_RVM_MEMORY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-463_RUVECTOR_MANIFEST_RVM_PARTITION",
    "packet": "generated/execution_packets/COMPONENT-463_RUVECTOR_MANIFEST_RVM_PARTITION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-464_RUVECTOR_MANIFEST_RVM_PROOF",
    "packet": "generated/execution_packets/COMPONENT-464_RUVECTOR_MANIFEST_RVM_PROOF.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-465_RUVECTOR_MANIFEST_RVM_SCHED",
    "packet": "generated/execution_packets/COMPONENT-465_RUVECTOR_MANIFEST_RVM_SCHED.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-466_RUVECTOR_MANIFEST_RVM_SECURITY",
    "packet": "generated/execution_packets/COMPONENT-466_RUVECTOR_MANIFEST_RVM_SECURITY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-467_RUVECTOR_MANIFEST_RVM_TYPES",
    "packet": "generated/execution_packets/COMPONENT-467_RUVECTOR_MANIFEST_RVM_TYPES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-468_RUVECTOR_MANIFEST_RVM_WASM",
    "packet": "generated/execution_packets/COMPONENT-468_RUVECTOR_MANIFEST_RVM_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-469_RUVECTOR_MANIFEST_RVM_WITNESS",
    "packet": "generated/execution_packets/COMPONENT-469_RUVECTOR_MANIFEST_RVM_WITNESS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-470_RUVECTOR_MANIFEST_RVM_TESTS",
    "packet": "generated/execution_packets/COMPONENT-470_RUVECTOR_MANIFEST_RVM_TESTS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-471_RUVECTOR_MANIFEST_SONIC_CT_WASM",
    "packet": "generated/execution_packets/COMPONENT-471_RUVECTOR_MANIFEST_SONIC_CT_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-472_RUVECTOR_MANIFEST_SONIC_CT",
    "packet": "generated/execution_packets/COMPONENT-472_RUVECTOR_MANIFEST_SONIC_CT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-473_RUVECTOR_MANIFEST_MUSICA",
    "packet": "generated/execution_packets/COMPONENT-473_RUVECTOR_MANIFEST_MUSICA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-474_RUVECTOR_MANIFEST_OSPIPE",
    "packet": "generated/execution_packets/COMPONENT-474_RUVECTOR_MANIFEST_OSPIPE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-475_RUVECTOR_MANIFEST_EXAMPLES_DATA",
    "packet": "generated/execution_packets/COMPONENT-475_RUVECTOR_MANIFEST_EXAMPLES_DATA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-476_RUVECTOR_MANIFEST_RUVECTOR_DATA_CLIMATE",
    "packet": "generated/execution_packets/COMPONENT-476_RUVECTOR_MANIFEST_RUVECTOR_DATA_CLIMATE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-477_RUVECTOR_MANIFEST_RUVECTOR_DATA_EDGAR",
    "packet": "generated/execution_packets/COMPONENT-477_RUVECTOR_MANIFEST_RUVECTOR_DATA_EDGAR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-478_RUVECTOR_MANIFEST_RUVECTOR_DATA_FRAMEWORK",
    "packet": "generated/execution_packets/COMPONENT-478_RUVECTOR_MANIFEST_RUVECTOR_DATA_FRAMEWORK.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-479_RUVECTOR_MANIFEST_RUVECTOR_DATA_OPENALEX",
    "packet": "generated/execution_packets/COMPONENT-479_RUVECTOR_MANIFEST_RUVECTOR_DATA_OPENALEX.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-480_RUVECTOR_MANIFEST_DELTA_BEHAVIOR",
    "packet": "generated/execution_packets/COMPONENT-480_RUVECTOR_MANIFEST_DELTA_BEHAVIOR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-481_RUVECTOR_MANIFEST_RUVECTOR_EDGE_NET",
    "packet": "generated/execution_packets/COMPONENT-481_RUVECTOR_MANIFEST_RUVECTOR_EDGE_NET.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-482_RUVECTOR_MANIFEST_RUVECTOR_EDGE",
    "packet": "generated/execution_packets/COMPONENT-482_RUVECTOR_MANIFEST_RUVECTOR_EDGE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-483_RUVECTOR_MANIFEST_RUVECTOR_MMWAVE_SENSOR",
    "packet": "generated/execution_packets/COMPONENT-483_RUVECTOR_MANIFEST_RUVECTOR_MMWAVE_SENSOR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-484_RUVECTOR_MANIFEST_EXAMPLES_EXO_AI_2025",
    "packet": "generated/execution_packets/COMPONENT-484_RUVECTOR_MANIFEST_EXAMPLES_EXO_AI_2025.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-485_RUVECTOR_MANIFEST_EXO_BACKEND_CLASSICAL",
    "packet": "generated/execution_packets/COMPONENT-485_RUVECTOR_MANIFEST_EXO_BACKEND_CLASSICAL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-486_RUVECTOR_MANIFEST_EXO_CORE",
    "packet": "generated/execution_packets/COMPONENT-486_RUVECTOR_MANIFEST_EXO_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-487_RUVECTOR_MANIFEST_EXO_EXOTIC",
    "packet": "generated/execution_packets/COMPONENT-487_RUVECTOR_MANIFEST_EXO_EXOTIC.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-488_RUVECTOR_MANIFEST_EXO_FEDERATION",
    "packet": "generated/execution_packets/COMPONENT-488_RUVECTOR_MANIFEST_EXO_FEDERATION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-489_RUVECTOR_MANIFEST_EXO_HYPERGRAPH",
    "packet": "generated/execution_packets/COMPONENT-489_RUVECTOR_MANIFEST_EXO_HYPERGRAPH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-490_RUVECTOR_MANIFEST_EXO_MANIFOLD",
    "packet": "generated/execution_packets/COMPONENT-490_RUVECTOR_MANIFEST_EXO_MANIFOLD.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-491_RUVECTOR_MANIFEST_EXO_NODE",
    "packet": "generated/execution_packets/COMPONENT-491_RUVECTOR_MANIFEST_EXO_NODE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-492_RUVECTOR_MANIFEST_EXO_TEMPORAL",
    "packet": "generated/execution_packets/COMPONENT-492_RUVECTOR_MANIFEST_EXO_TEMPORAL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-493_RUVECTOR_MANIFEST_EXO_WASM",
    "packet": "generated/execution_packets/COMPONENT-493_RUVECTOR_MANIFEST_EXO_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-494_RUVECTOR_MANIFEST_NEUROMORPHIC_SPIKING",
    "packet": "generated/execution_packets/COMPONENT-494_RUVECTOR_MANIFEST_NEUROMORPHIC_SPIKING.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-495_RUVECTOR_MANIFEST_QUANTUM_COGNITIVE_SUPERPOS",
    "packet": "generated/execution_packets/COMPONENT-495_RUVECTOR_MANIFEST_QUANTUM_COGNITIVE_SUPERPOS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-496_RUVECTOR_MANIFEST_TIME_CRYSTAL_COGNITION",
    "packet": "generated/execution_packets/COMPONENT-496_RUVECTOR_MANIFEST_TIME_CRYSTAL_COGNITION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-497_RUVECTOR_MANIFEST_SPARSE_PERSISTENT_HOMOLOGY",
    "packet": "generated/execution_packets/COMPONENT-497_RUVECTOR_MANIFEST_SPARSE_PERSISTENT_HOMOLOGY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-498_RUVECTOR_MANIFEST_DEMAND_PAGED_COGNITION",
    "packet": "generated/execution_packets/COMPONENT-498_RUVECTOR_MANIFEST_DEMAND_PAGED_COGNITION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-499_RUVECTOR_MANIFEST_FEDERATED_COLLECTIVE_PHI",
    "packet": "generated/execution_packets/COMPONENT-499_RUVECTOR_MANIFEST_FEDERATED_COLLECTIVE_PHI.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-500_RUVECTOR_MANIFEST_CAUSAL_EMERGENCE",
    "packet": "generated/execution_packets/COMPONENT-500_RUVECTOR_MANIFEST_CAUSAL_EMERGENCE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-501_RUVECTOR_MANIFEST_META_SIM_CONSCIOUSNESS",
    "packet": "generated/execution_packets/COMPONENT-501_RUVECTOR_MANIFEST_META_SIM_CONSCIOUSNESS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-502_RUVECTOR_MANIFEST_HYPERBOLIC_ATTENTION",
    "packet": "generated/execution_packets/COMPONENT-502_RUVECTOR_MANIFEST_HYPERBOLIC_ATTENTION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-503_RUVECTOR_MANIFEST_THERMODYNAMIC_LEARNING",
    "packet": "generated/execution_packets/COMPONENT-503_RUVECTOR_MANIFEST_THERMODYNAMIC_LEARNING.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-504_RUVECTOR_MANIFEST_CONSCIOUS_LANGUAGE_INTERFA",
    "packet": "generated/execution_packets/COMPONENT-504_RUVECTOR_MANIFEST_CONSCIOUS_LANGUAGE_INTERFA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-505_RUVECTOR_MANIFEST_MINCUT_EXAMPLES",
    "packet": "generated/execution_packets/COMPONENT-505_RUVECTOR_MANIFEST_MINCUT_EXAMPLES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-506_RUVECTOR_MANIFEST_TEMPORAL_ATTRACTORS_MINCUT",
    "packet": "generated/execution_packets/COMPONENT-506_RUVECTOR_MANIFEST_TEMPORAL_ATTRACTORS_MINCUT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-507_RUVECTOR_MANIFEST_RUVECTOR_ONNX_EMBEDDINGS_W",
    "packet": "generated/execution_packets/COMPONENT-507_RUVECTOR_MANIFEST_RUVECTOR_ONNX_EMBEDDINGS_W.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-508_RUVECTOR_MANIFEST_RUVECTOR_ONNX_EMBEDDINGS",
    "packet": "generated/execution_packets/COMPONENT-508_RUVECTOR_MANIFEST_RUVECTOR_ONNX_EMBEDDINGS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-509_RUVECTOR_MANIFEST_PRIME_RADIANT_CATEGORY",
    "packet": "generated/execution_packets/COMPONENT-509_RUVECTOR_MANIFEST_PRIME_RADIANT_CATEGORY.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-510_RUVECTOR_MANIFEST_PRIME_RADIANT_ADVANCED_WAS",
    "packet": "generated/execution_packets/COMPONENT-510_RUVECTOR_MANIFEST_PRIME_RADIANT_ADVANCED_WAS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-511_RUVECTOR_MANIFEST_RUVLLM",
    "packet": "generated/execution_packets/COMPONENT-511_RUVECTOR_MANIFEST_RUVLLM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-512_RUVECTOR_MANIFEST_RUVLLM_ESP32_FLASH",
    "packet": "generated/execution_packets/COMPONENT-512_RUVECTOR_MANIFEST_RUVLLM_ESP32_FLASH.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-513_RUVECTOR_MANIFEST_RUVLLM_ESP32",
    "packet": "generated/execution_packets/COMPONENT-513_RUVECTOR_MANIFEST_RUVLLM_ESP32.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-514_RUVECTOR_MANIFEST_RVF_DESKTOP",
    "packet": "generated/execution_packets/COMPONENT-514_RUVECTOR_MANIFEST_RVF_DESKTOP.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-515_RUVECTOR_MANIFEST_SPIKING_NETWORK",
    "packet": "generated/execution_packets/COMPONENT-515_RUVECTOR_MANIFEST_SPIKING_NETWORK.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-516_RUVECTOR_MANIFEST_ULTRA_LOW_LATENCY_SIM",
    "packet": "generated/execution_packets/COMPONENT-516_RUVECTOR_MANIFEST_ULTRA_LOW_LATENCY_SIM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-517_RUVECTOR_MANIFEST_EXAMPLES_VIBECAST_7SENSE",
    "packet": "generated/execution_packets/COMPONENT-517_RUVECTOR_MANIFEST_EXAMPLES_VIBECAST_7SENSE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-518_RUVECTOR_MANIFEST_SEVENSENSE_ANALYSIS",
    "packet": "generated/execution_packets/COMPONENT-518_RUVECTOR_MANIFEST_SEVENSENSE_ANALYSIS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-519_RUVECTOR_MANIFEST_SEVENSENSE_API",
    "packet": "generated/execution_packets/COMPONENT-519_RUVECTOR_MANIFEST_SEVENSENSE_API.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-520_RUVECTOR_MANIFEST_SEVENSENSE_AUDIO",
    "packet": "generated/execution_packets/COMPONENT-520_RUVECTOR_MANIFEST_SEVENSENSE_AUDIO.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-521_RUVECTOR_MANIFEST_SEVENSENSE_BENCHES",
    "packet": "generated/execution_packets/COMPONENT-521_RUVECTOR_MANIFEST_SEVENSENSE_BENCHES.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-522_RUVECTOR_MANIFEST_SEVENSENSE_CORE",
    "packet": "generated/execution_packets/COMPONENT-522_RUVECTOR_MANIFEST_SEVENSENSE_CORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-523_RUVECTOR_MANIFEST_SEVENSENSE_EMBEDDING",
    "packet": "generated/execution_packets/COMPONENT-523_RUVECTOR_MANIFEST_SEVENSENSE_EMBEDDING.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-524_RUVECTOR_MANIFEST_SEVENSENSE_INTERPRETATION",
    "packet": "generated/execution_packets/COMPONENT-524_RUVECTOR_MANIFEST_SEVENSENSE_INTERPRETATION.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-525_RUVECTOR_MANIFEST_SEVENSENSE_LEARNING",
    "packet": "generated/execution_packets/COMPONENT-525_RUVECTOR_MANIFEST_SEVENSENSE_LEARNING.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-526_RUVECTOR_MANIFEST_SEVENSENSE_VECTOR",
    "packet": "generated/execution_packets/COMPONENT-526_RUVECTOR_MANIFEST_SEVENSENSE_VECTOR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-527_RUVECTOR_MANIFEST_PERFORMANCE_REPORT",
    "packet": "generated/execution_packets/COMPONENT-527_RUVECTOR_MANIFEST_PERFORMANCE_REPORT.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-528_RUVECTOR_MANIFEST_VIBECAST_TESTS",
    "packet": "generated/execution_packets/COMPONENT-528_RUVECTOR_MANIFEST_VIBECAST_TESTS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-529_RUVECTOR_MANIFEST_RUVECTOR_IOS_WASM",
    "packet": "generated/execution_packets/COMPONENT-529_RUVECTOR_MANIFEST_RUVECTOR_IOS_WASM.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-530_RUVECTOR_MANIFEST_HNSW_RS",
    "packet": "generated/execution_packets/COMPONENT-530_RUVECTOR_MANIFEST_HNSW_RS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-531_RUVECTOR_MANIFEST_HNSW_RS",
    "packet": "generated/execution_packets/COMPONENT-531_RUVECTOR_MANIFEST_HNSW_RS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-532_RUVECTOR_MANIFEST_RUVECTOR_ATTENTION_INTEGRA",
    "packet": "generated/execution_packets/COMPONENT-532_RUVECTOR_MANIFEST_RUVECTOR_ATTENTION_INTEGRA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-533_RUVECTOR_NAMED_SURFACE_RUVECTOR_HNSW_REPAIR",
    "packet": "generated/execution_packets/COMPONENT-533_RUVECTOR_NAMED_SURFACE_RUVECTOR_HNSW_REPAIR.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-534_RUVECTOR_NAMED_SURFACE_RUVECTOR_SPARSE_INFER",
    "packet": "generated/execution_packets/COMPONENT-534_RUVECTOR_NAMED_SURFACE_RUVECTOR_SPARSE_INFER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-535_RUVECTOR_NAMED_SURFACE_RUVECTOR_ATTENTION_CL",
    "packet": "generated/execution_packets/COMPONENT-535_RUVECTOR_NAMED_SURFACE_RUVECTOR_ATTENTION_CL.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-536_RUVECTOR_NAMED_SURFACE_RUVECTOR_MINCUT_BRAIN",
    "packet": "generated/execution_packets/COMPONENT-536_RUVECTOR_NAMED_SURFACE_RUVECTOR_MINCUT_BRAIN.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-537_RUVECTOR_NAMED_SURFACE_RUVECTOR_TEMPORAL_TEN",
    "packet": "generated/execution_packets/COMPONENT-537_RUVECTOR_NAMED_SURFACE_RUVECTOR_TEMPORAL_TEN.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-538_RUVECTOR_NAMED_SURFACE_RUVECTOR_TIMESFM_FORE",
    "packet": "generated/execution_packets/COMPONENT-538_RUVECTOR_NAMED_SURFACE_RUVECTOR_TIMESFM_FORE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-539_RUVECTOR_NAMED_SURFACE_RUVLLM_BRIDGE",
    "packet": "generated/execution_packets/COMPONENT-539_RUVECTOR_NAMED_SURFACE_RUVLLM_BRIDGE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-540_RUVECTOR_NAMED_SURFACE_RUVLLM_EMBEDDER",
    "packet": "generated/execution_packets/COMPONENT-540_RUVECTOR_NAMED_SURFACE_RUVLLM_EMBEDDER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-541_RUVECTOR_NAMED_SURFACE_RUVLLM_PI_WORKER",
    "packet": "generated/execution_packets/COMPONENT-541_RUVECTOR_NAMED_SURFACE_RUVLLM_PI_WORKER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-542_RUVECTOR_NAMED_SURFACE_MCP_BRAIN_SERVER_LOCA",
    "packet": "generated/execution_packets/COMPONENT-542_RUVECTOR_NAMED_SURFACE_MCP_BRAIN_SERVER_LOCA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-543_RUVECTOR_NAMED_SURFACE_RUVECTOR_HAILO_EMBED",
    "packet": "generated/execution_packets/COMPONENT-543_RUVECTOR_NAMED_SURFACE_RUVECTOR_HAILO_EMBED.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-544_RUVECTOR_NAMED_SURFACE_RUVECTOR_HAILO_WORKER",
    "packet": "generated/execution_packets/COMPONENT-544_RUVECTOR_NAMED_SURFACE_RUVECTOR_HAILO_WORKER.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-545_RUVECTOR_NAMED_SURFACE_RUVECTOR_HAILO_STATS",
    "packet": "generated/execution_packets/COMPONENT-545_RUVECTOR_NAMED_SURFACE_RUVECTOR_HAILO_STATS.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-546_RUVECTOR_NAMED_SURFACE_RUVECTOR_MMWAVE_BRIDG",
    "packet": "generated/execution_packets/COMPONENT-546_RUVECTOR_NAMED_SURFACE_RUVECTOR_MMWAVE_BRIDG.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-547_LIFEOS_AGENTDB_SCHEMA",
    "packet": "generated/execution_packets/COMPONENT-547_LIFEOS_AGENTDB_SCHEMA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-548_LIFEOS_RVF_SCHEMA",
    "packet": "generated/execution_packets/COMPONENT-548_LIFEOS_RVF_SCHEMA.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D01_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D01_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D02_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D02_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D03_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D03_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D04_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D04_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D05_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D05_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D06_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D06_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D07_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D07_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D08_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D08_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D09_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D09_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D10_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D10_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D11_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D11_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D12_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D12_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D13_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D13_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D14_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D14_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D15_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D15_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D16_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D16_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D17_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D17_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D18_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D18_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D19_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D19_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D20_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D20_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D21_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D21_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D22_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D22_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D23_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D23_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D24_ATLAS_ENTRY",
    "packet": "generated/execution_packets/DIAGRAM-D24_ATLAS_ENTRY.json",
    "reason": "probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-001_PHYSICAL_PIPELINE",
    "packet": "generated/execution_packets/PIPELINE-001_PHYSICAL_PIPELINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-002_PHYSICAL_PIPELINE",
    "packet": "generated/execution_packets/PIPELINE-002_PHYSICAL_PIPELINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-003_PHYSICAL_PIPELINE",
    "packet": "generated/execution_packets/PIPELINE-003_PHYSICAL_PIPELINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-004_PHYSICAL_PIPELINE",
    "packet": "generated/execution_packets/PIPELINE-004_PHYSICAL_PIPELINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-005_PHYSICAL_PIPELINE",
    "packet": "generated/execution_packets/PIPELINE-005_PHYSICAL_PIPELINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-006_PHYSICAL_PIPELINE",
    "packet": "generated/execution_packets/PIPELINE-006_PHYSICAL_PIPELINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-007_PHYSICAL_PIPELINE",
    "packet": "generated/execution_packets/PIPELINE-007_PHYSICAL_PIPELINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-008_PHYSICAL_PIPELINE",
    "packet": "generated/execution_packets/PIPELINE-008_PHYSICAL_PIPELINE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R01_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R01_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R02_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R02_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R03_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R03_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R04_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R04_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R05_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R05_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R06_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R06_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R07_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R07_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R08_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R08_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R09_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R09_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R10_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R10_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R11_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R11_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R12_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R12_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R13_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R13_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R14_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R14_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R15_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R15_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R16_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R16_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R17_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R17_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R18_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R18_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R19_LEDGER_ROW",
    "packet": "generated/execution_packets/REVIEW-R19_LEDGER_ROW.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-001_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-001_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-002_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-002_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-003_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-003_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-004_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-004_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-005_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-005_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-006_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-006_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-007_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-007_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-008_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-008_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-009_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-009_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-010_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-010_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-011_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-011_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-012_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-012_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-013_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-013_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-014_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-014_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-015_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-015_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-016_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-016_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-017_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-017_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-018_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-018_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-019_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-019_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-020_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-020_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-021_HARD_EXECUTION_RULE",
    "packet": "generated/execution_packets/RULE-021_HARD_EXECUTION_RULE.json",
    "reason": "needs_capability_probe is true; probe_class is drift-canary; packet explicitly disclaims implementation evidence; implementation scope is not_claimed"
  }
]

## Non-implementation completion proofs
[
  {
    "task_id": "ANCHOR-A01_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A02_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A03_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A04_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A05_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A06_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A07_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A08_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A09_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A10_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A11_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A12_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A13_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A14_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ANCHOR-A15_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "ART-100_SYSTEM_INVENTORY",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-101_DIRECTORY_TREE",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-102_REPOSITORY_MAP",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-103_SERVICE_DEP_GRAPH",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "ART-104_TOOLCHAIN_TREE",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-105_PACKAGE_LIB_GRAPH",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-106_RUNTIME_DEP_MAP",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-107_DATA_FLOW_GRAPH",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-108_DB_SCHEMA_MAP",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-109_DATA_LINEAGE",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-110_API_CATALOG",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-111_EVENT_MAP",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-112_CODE_OWNERSHIP",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-113_DEBUG_CODE_MAP",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-114_ENV_CONFIG_MATRIX",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-115_CONFIG_INVENTORY",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-116_INFRA_TOPOLOGY",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-117_IAM_MATRIX",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-118_OBSERVABILITY",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-119_BUSINESS_PROCESS",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-120_WAVE_PLAN",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-121_CUTOVER",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "ART-122_ROLLBACK",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-123_VALIDATION_RECONCILIATION",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-124_TEST_COVERAGE",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-125_RISK_REGISTER",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-126_DECISION_LOG",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-127_BLAST_RADIUS",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-128_READINESS_SCORECARD",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-129_BUSINESS_CAPABILITY",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-130_SHADOW_TRAFFIC",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-131_GOLDEN_DATASET",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-132_PARITY_DASHBOARD",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "ART-133_DEPRECATION_MAP",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-134_EXCEPTION_INVENTORY",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-135_RACI",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "ART-136_TECH_DEBT_LEDGER",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "COMPONENT-001_POSTGRESQL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-002_RUVECTOR_POSTGRESQL_EXTENSION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-003_RUVECTOR_CORE_SERVICE_RUNTIME",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-004_RUVECTOR_RETRIEVAL_INDEX_FAMILY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-005_RUVECTOR_GRAPH_RDF_DAG_FAMILY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-006_RUVECTOR_GNN_ATTENTION_CNN_FAMILY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-007_RUVECTOR_MINCUT_HEALING_PERCEPTION_FAMILY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-008_FASTGRNN_AND_TINY_DANCER_ROUTING",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-009_SONA_AND_REINFORCEMENT_LEARNING",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-010_RUVLLM_AND_RUVLTRA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-011_AGENTDB",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-012_RVF",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-013_PROOF_AND_WITNESS_RUNTIME",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-014_RUFLO",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-015_ATAS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-016_REDB",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-017_ENVCTL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-018_SECRET_ENGINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-019_SECRET_BROKER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-020_SECRET_MINT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-021_SEED_VAULT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-022_COGNITUM_SEED",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-023_SECRET_RELAY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-024_NU_PLUGIN_CODEDB",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-025_RTK",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-026_RTK_NU",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-027_NUSHELL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-028_YAZELIX_ZELLIJ_HELIX_YAZI_NEOVIM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-029_LIFEOS_AND_CODEX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-030_GIT_GITKB_META_BEADS_BR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-031_ICM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-032_WEAVE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-033_NETWORK_CONTROL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-034_FLEXNETOS_RUNNER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-035_RUSTY_IDD_HF",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-036_NIX_COMPILERS_BUN_NAPI_WASM_AND_MUSL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-037_GPU_ONNX_CANDLE_AND_MODEL_DRIVERS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-038_RUVIX_RVAGENT_HARDWARE_AND_SPECIALIZED_RUVEC",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-039_RUVECTOR_MEMBER_RUVECTOR_TEMPORAL_COHERENCE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-040_RUVECTOR_MEMBER_RUVECTOR_ACORN",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-041_RUVECTOR_MEMBER_RUVECTOR_ACORN_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-042_RUVECTOR_MEMBER_RUVECTOR_COHERENCE_HNSW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-043_RUVECTOR_MEMBER_RUVECTOR_RABITQ",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-044_RUVECTOR_MEMBER_RUVECTOR_RABITQ_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-045_RUVECTOR_MEMBER_RUVECTOR_RULAKE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-046_RUVECTOR_MEMBER_RUVECTOR_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-047_RUVECTOR_MEMBER_RUVECTOR_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-048_RUVECTOR_MEMBER_RUVECTOR_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-049_RUVECTOR_MEMBER_RUVECTOR_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-050_RUVECTOR_MEMBER_RUVECTOR_BENCH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-051_RUVECTOR_MEMBER_RUVECTOR_METRICS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-052_RUVECTOR_MEMBER_RUVECTOR_FILTER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-053_RUVECTOR_MEMBER_RUVECTOR_ROUTER_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-054_RUVECTOR_MEMBER_RUVECTOR_ROUTER_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-055_RUVECTOR_MEMBER_RUVECTOR_ROUTER_FFI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-056_RUVECTOR_MEMBER_RUVECTOR_ROUTER_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-057_RUVECTOR_MEMBER_RUVECTOR_SERVER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-058_RUVECTOR_MEMBER_RUVECTOR_SNAPSHOT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-059_RUVECTOR_MEMBER_RUVECTOR_TINY_DANCER_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-060_RUVECTOR_MEMBER_RUVECTOR_TINY_DANCER_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-061_RUVECTOR_MEMBER_RUVECTOR_TINY_DANCER_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-062_RUVECTOR_MEMBER_RUVECTOR_COLLECTIONS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-063_RUVECTOR_MEMBER_RUVECTOR_CLUSTER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-064_RUVECTOR_MEMBER_RUVECTOR_RAFT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-065_RUVECTOR_MEMBER_RUVECTOR_REPLICATION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-066_RUVECTOR_MEMBER_RUVECTOR_GRAPH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-067_RUVECTOR_MEMBER_RUVECTOR_GRAPH_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-068_RUVECTOR_MEMBER_RUVECTOR_GRAPH_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-069_RUVECTOR_MEMBER_RUVECTOR_GNN",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-070_RUVECTOR_MEMBER_RUVECTOR_PROOF_GATE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-071_RUVECTOR_MEMBER_RUVECTOR_GNN_RERANK",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-072_RUVECTOR_MEMBER_RUVECTOR_GNN_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-073_RUVECTOR_MEMBER_RUVECTOR_GNN_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-074_RUVECTOR_MEMBER_RUVECTOR_ATTENTION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-075_RUVECTOR_MEMBER_RUVECTOR_ATTENTION_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-076_RUVECTOR_MEMBER_RUVECTOR_ATTENTION_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-077_RUVECTOR_MEMBER_RUVECTOR_CNN",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-078_RUVECTOR_MEMBER_RUVECTOR_CNN_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-079_RUVECTOR_MEMBER_RUVECTOR_MINCUT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-080_RUVECTOR_MEMBER_RUVECTOR_MINCUT_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-081_RUVECTOR_MEMBER_RUVECTOR_MINCUT_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-082_RUVECTOR_MEMBER_RUVECTOR_MINCUT_GATED_TRANSF",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-083_RUVECTOR_MEMBER_RUVECTOR_MINCUT_GATED_TRANSF",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-084_RUVECTOR_MEMBER_RUVECTOR_NERVOUS_SYSTEM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-085_RUVECTOR_MEMBER_HAILORT_SYS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-086_RUVECTOR_MEMBER_RUVECTOR_HAILO",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-087_RUVECTOR_MEMBER_RUVECTOR_MMWAVE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-088_RUVECTOR_MEMBER_RUVECTOR_HAILO_CLUSTER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-089_RUVECTOR_MEMBER_REFRAG_PIPELINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-090_RUVECTOR_MEMBER_SCIPIX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-091_RUVECTOR_MEMBER_GOOGLE_CLOUD",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-092_RUVECTOR_MEMBER_SUBPOLYNOMIAL_TIME",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-093_RUVECTOR_MEMBER_RUVECTOR_SONA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-094_RUVECTOR_MEMBER_RVLITE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-095_RUVECTOR_MEMBER_RUVECTOR_DAG",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-096_RUVECTOR_MEMBER_RUVECTOR_DAG_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-097_RUVECTOR_MEMBER_RUVECTOR_NERVOUS_SYSTEM_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-098_RUVECTOR_MEMBER_RUVECTOR_ECONOMY_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-099_RUVECTOR_MEMBER_RUVECTOR_LEARNING_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-100_RUVECTOR_MEMBER_RUVECTOR_EXOTIC_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-101_RUVECTOR_MEMBER_RUVECTOR_ATTENTION_UNIFIED_W",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-102_RUVECTOR_MEMBER_RUVECTOR_FPGA_TRANSFORMER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-103_RUVECTOR_MEMBER_RUVECTOR_FPGA_TRANSFORMER_WA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-104_RUVECTOR_MEMBER_RUVECTOR_SPARSE_INFERENCE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-105_RUVECTOR_MEMBER_RUVECTOR_MATH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-106_RUVECTOR_MEMBER_RUVECTOR_MATH_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-107_RUVECTOR_MEMBER_BENCHMARKS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-108_RUVECTOR_MEMBER_COGNITUM_GATE_KERNEL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-109_RUVECTOR_MEMBER_COGNITUM_GATE_TILEZERO",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-110_RUVECTOR_MEMBER_MCP_GATE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-111_RUVECTOR_MEMBER_MCP_BRAIN",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-112_RUVECTOR_MEMBER_MCP_BRAIN_SERVER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-113_RUVECTOR_MEMBER_RUVLLM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-114_RUVECTOR_MEMBER_RUVLLM_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-115_RUVECTOR_MEMBER_RUVLLM_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-116_RUVECTOR_MEMBER_PRIME_RADIANT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-117_RUVECTOR_MEMBER_RUVECTOR_DELTA_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-118_RUVECTOR_MEMBER_RUVECTOR_DELTA_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-119_RUVECTOR_MEMBER_RUVECTOR_DELTA_INDEX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-120_RUVECTOR_MEMBER_RUVECTOR_DELTA_GRAPH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-121_RUVECTOR_MEMBER_RUVECTOR_DELTA_CONSENSUS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-122_RUVECTOR_MEMBER_RUVECTOR_CRV",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-123_RUVECTOR_MEMBER_RUVECTOR_TEMPORAL_TENSOR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-124_RUVECTOR_MEMBER_RUVECTOR_DOMAIN_EXPANSION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-125_RUVECTOR_MEMBER_RUVECTOR_DOMAIN_EXPANSION_WA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-126_RUVECTOR_MEMBER_RUVECTOR_SOLVER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-127_RUVECTOR_MEMBER_RUVECTOR_SOLVER_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-128_RUVECTOR_MEMBER_RUVECTOR_SOLVER_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-129_RUVECTOR_MEMBER_RUVECTOR_COHERENCE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-130_RUVECTOR_MEMBER_RUVECTOR_PROFILER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-131_RUVECTOR_MEMBER_RUVECTOR_ATTN_MINCUT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-132_RUVECTOR_MEMBER_RUVECTOR_COGNITIVE_CONTAINER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-133_RUVECTOR_MEMBER_RUVECTOR_VERIFIED",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-134_RUVECTOR_MEMBER_RUVECTOR_VERIFIED_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-135_RUVECTOR_MEMBER_RUVECTOR_GRAPH_TRANSFORMER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-136_RUVECTOR_MEMBER_RUVECTOR_GRAPH_TRANSFORMER_W",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-137_RUVECTOR_MEMBER_RUVECTOR_GRAPH_TRANSFORMER_N",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-138_RUVECTOR_MEMBER_RVF_KERNEL_OPTIMIZED",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-139_RUVECTOR_MEMBER_VERIFIED_APPLICATIONS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-140_RUVECTOR_MEMBER_THERMORUST",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-141_RUVECTOR_MEMBER_RUVECTOR_DITHER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-142_RUVECTOR_MEMBER_RUVECTOR_ROBOTICS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-143_RUVECTOR_MEMBER_ROBOTICS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-144_RUVECTOR_MEMBER_NEURAL_TRADER_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-145_RUVECTOR_MEMBER_NEURAL_TRADER_COHERENCE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-146_RUVECTOR_MEMBER_NEURAL_TRADER_REPLAY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-147_RUVECTOR_MEMBER_NEURAL_TRADER_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-148_RUVECTOR_MEMBER_RUVECTOR_KALSHI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-149_RUVECTOR_MEMBER_NEURAL_TRADER_STRATEGIES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-150_RUVECTOR_MEMBER_TYPES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-151_RUVECTOR_MEMBER_REGION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-152_RUVECTOR_MEMBER_QUEUE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-153_RUVECTOR_MEMBER_CAP",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-154_RUVECTOR_MEMBER_PROOF",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-155_RUVECTOR_MEMBER_SCHED",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-156_RUVECTOR_MEMBER_BOOT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-157_RUVECTOR_MEMBER_VECGRAPH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-158_RUVECTOR_MEMBER_NUCLEUS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-159_RUVECTOR_MEMBER_HAL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-160_RUVECTOR_MEMBER_AARCH64",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-161_RUVECTOR_MEMBER_DRIVERS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-162_RUVECTOR_MEMBER_TESTS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-163_RUVECTOR_MEMBER_BENCHES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-164_RUVECTOR_MEMBER_COGNITIVE_DEMO",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-165_RUVECTOR_MEMBER_RVAGENT_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-166_RUVECTOR_MEMBER_RVAGENT_BACKENDS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-167_RUVECTOR_MEMBER_RVAGENT_MIDDLEWARE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-168_RUVECTOR_MEMBER_RVAGENT_TOOLS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-169_RUVECTOR_MEMBER_RVAGENT_SUBAGENTS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-170_RUVECTOR_MEMBER_RVAGENT_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-171_RUVECTOR_MEMBER_RVAGENT_ACP",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-172_RUVECTOR_MEMBER_RVAGENT_MCP",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-173_RUVECTOR_MEMBER_RVAGENT_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-174_RUVECTOR_MEMBER_RVAGENT_A2A",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-175_RUVECTOR_MEMBER_A2A_SWARM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-176_RUVECTOR_MEMBER_TRAIN_DISCOVERIES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-177_RUVECTOR_MEMBER_SKY_MONITOR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-178_RUVECTOR_MEMBER_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-179_RUVECTOR_MEMBER_RUVECTOR_SPARSIFIER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-180_RUVECTOR_MEMBER_RUVECTOR_SPARSIFIER_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-181_RUVECTOR_MEMBER_RUVECTOR_CONSCIOUSNESS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-182_RUVECTOR_MEMBER_RUVECTOR_CONSCIOUSNESS_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-183_RUVECTOR_MEMBER_CMB_CONSCIOUSNESS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-184_RUVECTOR_MEMBER_GW_CONSCIOUSNESS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-185_RUVECTOR_MEMBER_ECOSYSTEM_CONSCIOUSNESS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-186_RUVECTOR_MEMBER_QUANTUM_CONSCIOUSNESS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-187_RUVECTOR_MEMBER_GENE_CONSCIOUSNESS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-188_RUVECTOR_MEMBER_CLIMATE_CONSCIOUSNESS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-189_RUVECTOR_MEMBER_RUVECTOR_DECOMPILER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-190_RUVECTOR_MEMBER_RUVECTOR_DECOMPILER_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-191_RUVECTOR_MEMBER_RUVECTOR_DISKANN",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-192_RUVECTOR_MEMBER_RUVECTOR_DISKANN_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-193_RUVECTOR_MEMBER_BOUNDARY_DISCOVERY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-194_RUVECTOR_MEMBER_CMB_BOUNDARY_DISCOVERY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-195_RUVECTOR_MEMBER_FRB_BOUNDARY_DISCOVERY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-196_RUVECTOR_MEMBER_VOID_BOUNDARY_DISCOVERY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-197_RUVECTOR_MEMBER_TEMPORAL_ATTRACTOR_DISCOVERY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-198_RUVECTOR_MEMBER_MUSIC_BOUNDARY_DISCOVERY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-199_RUVECTOR_MEMBER_WEATHER_BOUNDARY_DISCOVERY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-200_RUVECTOR_MEMBER_MARKET_BOUNDARY_DISCOVERY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-201_RUVECTOR_MEMBER_HEALTH_BOUNDARY_DISCOVERY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-202_RUVECTOR_MEMBER_SETI_EXOTIC_SIGNALS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-203_RUVECTOR_MEMBER_SETI_BOUNDARY_DISCOVERY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-204_RUVECTOR_MEMBER_EARTHQUAKE_BOUNDARY_DISCOVER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-205_RUVECTOR_MEMBER_PANDEMIC_BOUNDARY_DISCOVERY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-206_RUVECTOR_MEMBER_INFRASTRUCTURE_BOUNDARY_DISC",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-207_RUVECTOR_MEMBER_BRAIN_BOUNDARY_DISCOVERY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-208_RUVECTOR_MEMBER_SEIZURE_CLINICAL_REPORT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-209_RUVECTOR_MEMBER_SEIZURE_THERAPEUTIC_SIM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-210_RUVECTOR_MEMBER_REAL_EEG_ANALYSIS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-211_RUVECTOR_MEMBER_REAL_EEG_MULTI_SEIZURE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-212_RUVECTOR_MEMBER_RUVLLM_SPARSE_ATTENTION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-213_RUVECTOR_MEMBER_RUVLLM_RETRIEVAL_DIFFUSION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-214_RUVECTOR_MEMBER_RUVECTOR_RAIRS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-215_RUVECTOR_MEMBER_RUVECTOR_HYBRID",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-216_RUVECTOR_MEMBER_RUVECTOR_LSM_ANN",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-217_RUVECTOR_MEMBER_RUVECTOR_GRAPH_CONDENSE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-218_RUVECTOR_MEMBER_RUVECTOR_GRAPH_CONDENSE_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-219_RUVECTOR_MEMBER_RUVECTOR_PERCEPTION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-220_RUVECTOR_MEMBER_EMERGENT_TIME",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-221_RUVECTOR_MEMBER_PHOTONLAYER_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-222_RUVECTOR_MEMBER_PHOTONLAYER_BENCH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-223_RUVECTOR_MEMBER_PHOTONLAYER_RUVECTOR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-224_RUVECTOR_MEMBER_PHOTONLAYER_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-225_RUVECTOR_MEMBER_PHOTONLAYER_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-226_RUVECTOR_MEMBER_RUVECTOR_MATRYOSHKA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-227_RUVECTOR_MEMBER_RUVECTOR_PQ_SEARCH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-228_RUVECTOR_MEMBER_RUVECTOR_SOTA_BENCH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-229_RUVECTOR_MEMBER_RUVECTOR_CAPGATED",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-230_RUVECTOR_MEMBER_RUVECTOR_SPANN",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-231_RUVECTOR_MEMBER_RUVECTOR_MAXSIM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-232_RUVECTOR_MEMBER_TIMESFM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-233_RUVECTOR_MEMBER_RUVECTOR_TIMESFM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-234_RVF_TYPES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-235_RVF_WIRE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-236_RVF_MANIFEST",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-237_RVF_INDEX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-238_RVF_QUANT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-239_RVF_CRYPTO",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-240_RVF_RUNTIME",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-241_RVF_KERNEL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-242_RVF_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-243_RVF_SOLVER_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-244_RVF_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-245_RVF_SERVER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-246_RVF_IMPORT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-247_RVF_ADAPTER_CLAUDE_FLOW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-248_RVF_ADAPTER_AGENTDB",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-249_RVF_ADAPTER_OSPIPE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-250_RVF_ADAPTER_AGENTIC_FLOW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-251_RVF_ADAPTER_RVLITE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-252_RVF_ADAPTER_SONA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-253_RVF_LAUNCH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-254_RVF_EBPF",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-255_RVF_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-256_RVF_INTEGRATION_TESTS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-257_RVF_BENCHES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-258_RVF_FEDERATION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-259_RUVECTOR_DETACHED_OSPIPE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-260_RUVECTOR_DETACHED_RVF_EXAMPLES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-261_RUVECTOR_DETACHED_MICRO_HNSW_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-262_RUVECTOR_DETACHED_RUVECTOR_HYPERBOLIC_HNSW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-263_RUVECTOR_DETACHED_RUVECTOR_HYPERBOLIC_HNSW_W",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-264_RUVECTOR_DETACHED_RUVLLM_ESP32",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-265_RUVECTOR_DETACHED_RUVLLM_ESP32_FLASH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-266_RUVECTOR_DETACHED_RUVECTOR_EDGE_NET",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-267_RUVECTOR_DETACHED_RUVECTOR_DATA_FRAMEWORK",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-268_RUVECTOR_DETACHED_RUVECTOR_DATA_OPENALEX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-269_RUVECTOR_DETACHED_RUVECTOR_DATA_CLIMATE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-270_RUVECTOR_DETACHED_RUVECTOR_DATA_EDGAR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-271_RUVECTOR_DETACHED_RUVLLM_EXAMPLES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-272_RUVECTOR_DETACHED_DELTA_BEHAVIOR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-273_RUVECTOR_DETACHED_RVF_DESKTOP",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-274_RUVECTOR_DETACHED_EMERGENT_TIME_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-275_RUVECTOR_DETACHED_SONIC_CT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-276_RUVECTOR_DETACHED_SONIC_CT_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-277_RUVECTOR_DETACHED_RUVECTOR_POSTGRES_DETACHED",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-278_RUVECTOR_DETACHED_RUOS_THERMAL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-279_RUVECTOR_DETACHED_EXTERNAL_RUQU",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-280_RUVECTOR_DETACHED_EXTERNAL_RVDNA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-281_RUVECTOR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-282_RUVECTOR_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-283_RUVECTOR_CORE_NATIVE_PLATFORMS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-284_RUVECTOR_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-285_RUVECTOR_ROUTER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-286_RUVECTOR_GNN",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-287_RUVECTOR_ATTENTION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-288_RUVECTOR_ATTENTION_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-289_RUVECTOR_RUVLLM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-290_RUVECTOR_RUVLLM_NATIVE_PLATFORMS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-291_RUVECTOR_RUVLLM_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-292_RUVECTOR_SONA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-293_RUVECTOR_SONA_NATIVE_PLATFORMS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-294_RUVECTOR_RVF",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-295_RUVECTOR_POSTGRES_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-296_LIFEOS_COMPONENT_SRC_TAURI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-297_LIFEOS_COMPONENT_LIFEOS_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-298_LIFEOS_COMPONENT_LIFEOS_DAEMON",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-299_LIFEOS_COMPONENT_LIFEOS_VUE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-300_ENVCTL_COMPONENT_AGENT_ENV",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-301_ENVCTL_COMPONENT_ENGINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-302_ENVCTL_COMPONENT_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-303_ENVCTL_COMPONENT_GUI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-304_ENVCTL_COMPONENT_SECRETS_ENGINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-305_ENVCTL_COMPONENT_SECRETS_PROTO",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-306_ENVCTL_COMPONENT_SECRETD",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-307_ENVCTL_COMPONENT_SECRETCTL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-308_ENVCTL_COMPONENT_SECRETS_STORE_LIBSQL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-309_WEAVE_COMPONENT_WEAVE_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-310_WEAVE_COMPONENT_WEAVE_INJECT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-311_WEAVE_COMPONENT_WEAVE_MCP",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-312_WEAVE_COMPONENT_WEAVE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-313_NETWORK_CONTROL_COMPONENT_NETENGINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-314_NETWORK_CONTROL_COMPONENT_NETCTL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-315_NETWORK_CONTROL_COMPONENT_NETCTL_GUI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-316_FLEXNETOS_RUNNER_COMPONENT_RUNNER_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-317_FLEXNETOS_RUNNER_COMPONENT_RUNNER_ACTIONS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-318_FLEXNETOS_RUNNER_COMPONENT_RUNNER_DISPATCH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-319_FLEXNETOS_RUNNER_COMPONENT_RUNNER_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-320_RUSTY_IDD_COMPONENT_WORK_ORDER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-321_RUSTY_IDD_COMPONENT_LEDGER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-322_RUSTY_IDD_COMPONENT_HANDOFF_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-323_RUSTY_IDD_COMPONENT_HANDOFF_POLICY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-324_RUSTY_IDD_COMPONENT_HANDOFF_SCHEMA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-325_RUSTY_IDD_COMPONENT_HANDOFF_LEASE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-326_RUSTY_IDD_COMPONENT_HANDOFF_HOOKS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-327_RUSTY_IDD_COMPONENT_HANDOFF_INDEX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-328_RUSTY_IDD_COMPONENT_HANDOFF_FLEET",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-329_RUSTY_IDD_COMPONENT_HANDOFF_DRIFT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-330_RUSTY_IDD_COMPONENT_HANDOFF_ROUTE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-331_RUSTY_IDD_COMPONENT_HANDOFF_TEST_SUPPORT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-332_RUSTY_IDD_COMPONENT_HANDOFF_SECRETS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-333_RUSTY_IDD_COMPONENT_HANDOFF_GATEKEEPER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-334_RUSTY_IDD_COMPONENT_HANDOFF_INTAKE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-335_RUSTY_IDD_COMPONENT_HF",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-336_RUSTY_IDD_COMPONENT_CRATES_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-337_RUSTY_IDD_COMPONENT_CRATES_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-338_RUSTY_IDD_COMPONENT_CRATES_RUNNER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-339_RUSTY_IDD_COMPONENT_CRATES_SPEC",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-340_RUSTY_IDD_COMPONENT_CRATES_TUI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-341_RUSTY_IDD_COMPONENT_CODEGRAPH_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-342_RUSTY_IDD_COMPONENT_CODEGRAPH_PARSER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-343_RUSTY_IDD_COMPONENT_REPOMIX_SHARED",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-344_RUSTY_IDD_COMPONENT_KNOWLEDGE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-345_RUSTY_IDD_COMPONENT_MERGE_TOOLS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-346_NU_PLUGIN_COMPONENT_CODEDB",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-347_NU_PLUGIN_COMPONENT_CODEDB_CARGO",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-348_NU_PLUGIN_COMPONENT_CODEDB_CONTEXT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-349_NU_PLUGIN_COMPONENT_CODEDB_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-350_NU_PLUGIN_COMPONENT_CODEDB_FIXTURES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-351_NU_PLUGIN_COMPONENT_CODEDB_BUILD_CAPTURE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-352_NU_PLUGIN_COMPONENT_CODEDB_MCP",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-353_NU_PLUGIN_COMPONENT_CODEDB_RUST_STATIC",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-354_NU_PLUGIN_COMPONENT_CODEDB_STORE_REDB",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-355_NU_PLUGIN_COMPONENT_CODEDB_STORE_PG",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-356_NU_PLUGIN_COMPONENT_NU_PLUGIN_CODEDB",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-357_ICM_COMPONENT_ICM_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-358_ICM_COMPONENT_ICM_STORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-359_ICM_COMPONENT_ICM_MCP",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-360_ICM_COMPONENT_ICM_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-361_META",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-362_GITKB",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-363_BEADS_RUST_BR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-364_YAZELIX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-365_YAZELIX_TERMINAL_SUPPORT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-366_RTK_NU",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-367_RUVLTRA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-368_MICROLORA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-369_ATAS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-370_CLAUDE_FLOW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-371_CLAUDE_FLOW_NEURAL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-372_CLAUDE_FLOW_MEMORY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-373_CLAUDE_FLOW_MCP",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-374_CLAUDE_FLOW_SHARED",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-375_ATC",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-376_FLEXNETOS_AGENT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-377_GIT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-378_NIX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-379_NUSHELL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-380_ZELLIJ",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-381_YAZI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-382_HELIX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-383_NEOVIM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-384_CODEX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-385_CLAUDE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-386_BUN_BUNX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-387_CARGO_PGRX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-388_NAPI_RS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-389_WASM_BINDGEN_WASM_PACK",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-390_CANDLE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-391_ONNX_RUNTIME_ORT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-392_CUDA_NVIDIA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-393_MUSL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-394_FENIX_KACHE_WILD",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-395_LANE_OBSCURA_IROH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-396_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_BENCHMARK",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-397_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-398_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_EMBEDDED",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-399_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_MCP",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-400_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-401_RUVECTOR_MANIFEST_AGENTIC_ROBOTICS_RT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-402_RUVECTOR_MANIFEST_EMERGENT_TIME_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-403_RUVECTOR_MANIFEST_MICRO_HNSW_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-404_RUVECTOR_MANIFEST_RUOS_THERMAL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-405_RUVECTOR_MANIFEST_RUVECTOR_AGENT_MEMORY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-406_RUVECTOR_MANIFEST_RUVECTOR_ATTENTION_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-407_RUVECTOR_MANIFEST_RUVECTOR_BET4_IVF_BENCH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-408_RUVECTOR_MANIFEST_RUVECTOR_CORE_FUZZ",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-409_RUVECTOR_MANIFEST_RUVECTOR_GRAPH_FUZZ",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-410_RUVECTOR_MANIFEST_RUVECTOR_HNSW_REPAIR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-411_RUVECTOR_MANIFEST_RUVECTOR_HYPERBOLIC_HNSW_W",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-412_RUVECTOR_MANIFEST_RUVECTOR_HYPERBOLIC_HNSW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-413_RUVECTOR_MANIFEST_RUVECTOR_MINCUT_BRAIN_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-414_RUVECTOR_MANIFEST_RUVECTOR_RAFT_FUZZ",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-415_RUVECTOR_MANIFEST_RUVECTOR_SPARSE_INFERENCE_",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-416_RUVECTOR_MANIFEST_RUVECTOR_TEMPORAL_TENSOR_W",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-417_RUVECTOR_MANIFEST_RUVIX_BCM2711",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-418_RUVECTOR_MANIFEST_RUVIX_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-419_RUVECTOR_MANIFEST_RUVIX_DMA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-420_RUVECTOR_MANIFEST_RUVIX_DTB",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-421_RUVECTOR_MANIFEST_RUVIX_FS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-422_RUVECTOR_MANIFEST_RUVIX_NET",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-423_RUVECTOR_MANIFEST_RUVIX_PHYSMEM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-424_RUVECTOR_MANIFEST_RUVIX_RPI_BOOT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-425_RUVECTOR_MANIFEST_RUVIX_SHELL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-426_RUVECTOR_MANIFEST_RUVIX_SMP",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-427_RUVECTOR_MANIFEST_RVF_SWARM_DEMO",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-428_RUVECTOR_MANIFEST_RUVIX_QEMU_SWARM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-429_RUVECTOR_MANIFEST_RVF_BENCHES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-430_RUVECTOR_MANIFEST_RVF_ADAPTER_AGENTDB",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-431_RUVECTOR_MANIFEST_RVF_ADAPTER_AGENTIC_FLOW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-432_RUVECTOR_MANIFEST_RVF_ADAPTER_CLAUDE_FLOW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-433_RUVECTOR_MANIFEST_RVF_ADAPTER_OSPIPE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-434_RUVECTOR_MANIFEST_RVF_ADAPTER_RVLITE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-435_RUVECTOR_MANIFEST_RVF_ADAPTER_SONA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-436_RUVECTOR_MANIFEST_RVF_CLI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-437_RUVECTOR_MANIFEST_RVF_CRYPTO",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-438_RUVECTOR_MANIFEST_RVF_EBPF",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-439_RUVECTOR_MANIFEST_RVF_FEDERATION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-440_RUVECTOR_MANIFEST_RVF_IMPORT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-441_RUVECTOR_MANIFEST_RVF_INDEX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-442_RUVECTOR_MANIFEST_RVF_KERNEL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-443_RUVECTOR_MANIFEST_RVF_LAUNCH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-444_RUVECTOR_MANIFEST_RVF_MANIFEST",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-445_RUVECTOR_MANIFEST_RVF_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-446_RUVECTOR_MANIFEST_RVF_QUANT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-447_RUVECTOR_MANIFEST_RVF_RUNTIME",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-448_RUVECTOR_MANIFEST_RVF_SERVER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-449_RUVECTOR_MANIFEST_RVF_SOLVER_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-450_RUVECTOR_MANIFEST_RVF_TYPES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-451_RUVECTOR_MANIFEST_RVF_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-452_RUVECTOR_MANIFEST_RVF_WIRE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-453_RUVECTOR_MANIFEST_RVF_INTEGRATION_TESTS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-454_RUVECTOR_MANIFEST_CRATES_RVM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-455_RUVECTOR_MANIFEST_RVM_BENCHES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-456_RUVECTOR_MANIFEST_RVM_BOOT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-457_RUVECTOR_MANIFEST_RVM_CAP",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-458_RUVECTOR_MANIFEST_RVM_CHECKPOINT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-459_RUVECTOR_MANIFEST_RVM_COHERENCE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-460_RUVECTOR_MANIFEST_RVM_HAL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-461_RUVECTOR_MANIFEST_RVM_KERNEL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-462_RUVECTOR_MANIFEST_RVM_MEMORY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-463_RUVECTOR_MANIFEST_RVM_PARTITION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-464_RUVECTOR_MANIFEST_RVM_PROOF",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-465_RUVECTOR_MANIFEST_RVM_SCHED",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-466_RUVECTOR_MANIFEST_RVM_SECURITY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-467_RUVECTOR_MANIFEST_RVM_TYPES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-468_RUVECTOR_MANIFEST_RVM_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-469_RUVECTOR_MANIFEST_RVM_WITNESS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-470_RUVECTOR_MANIFEST_RVM_TESTS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-471_RUVECTOR_MANIFEST_SONIC_CT_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-472_RUVECTOR_MANIFEST_SONIC_CT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-473_RUVECTOR_MANIFEST_MUSICA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-474_RUVECTOR_MANIFEST_OSPIPE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-475_RUVECTOR_MANIFEST_EXAMPLES_DATA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-476_RUVECTOR_MANIFEST_RUVECTOR_DATA_CLIMATE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-477_RUVECTOR_MANIFEST_RUVECTOR_DATA_EDGAR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-478_RUVECTOR_MANIFEST_RUVECTOR_DATA_FRAMEWORK",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-479_RUVECTOR_MANIFEST_RUVECTOR_DATA_OPENALEX",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-480_RUVECTOR_MANIFEST_DELTA_BEHAVIOR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-481_RUVECTOR_MANIFEST_RUVECTOR_EDGE_NET",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-482_RUVECTOR_MANIFEST_RUVECTOR_EDGE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-483_RUVECTOR_MANIFEST_RUVECTOR_MMWAVE_SENSOR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-484_RUVECTOR_MANIFEST_EXAMPLES_EXO_AI_2025",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-485_RUVECTOR_MANIFEST_EXO_BACKEND_CLASSICAL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-486_RUVECTOR_MANIFEST_EXO_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-487_RUVECTOR_MANIFEST_EXO_EXOTIC",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-488_RUVECTOR_MANIFEST_EXO_FEDERATION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-489_RUVECTOR_MANIFEST_EXO_HYPERGRAPH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-490_RUVECTOR_MANIFEST_EXO_MANIFOLD",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-491_RUVECTOR_MANIFEST_EXO_NODE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-492_RUVECTOR_MANIFEST_EXO_TEMPORAL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-493_RUVECTOR_MANIFEST_EXO_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-494_RUVECTOR_MANIFEST_NEUROMORPHIC_SPIKING",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-495_RUVECTOR_MANIFEST_QUANTUM_COGNITIVE_SUPERPOS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-496_RUVECTOR_MANIFEST_TIME_CRYSTAL_COGNITION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-497_RUVECTOR_MANIFEST_SPARSE_PERSISTENT_HOMOLOGY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-498_RUVECTOR_MANIFEST_DEMAND_PAGED_COGNITION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-499_RUVECTOR_MANIFEST_FEDERATED_COLLECTIVE_PHI",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-500_RUVECTOR_MANIFEST_CAUSAL_EMERGENCE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-501_RUVECTOR_MANIFEST_META_SIM_CONSCIOUSNESS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-502_RUVECTOR_MANIFEST_HYPERBOLIC_ATTENTION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-503_RUVECTOR_MANIFEST_THERMODYNAMIC_LEARNING",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-504_RUVECTOR_MANIFEST_CONSCIOUS_LANGUAGE_INTERFA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-505_RUVECTOR_MANIFEST_MINCUT_EXAMPLES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-506_RUVECTOR_MANIFEST_TEMPORAL_ATTRACTORS_MINCUT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-507_RUVECTOR_MANIFEST_RUVECTOR_ONNX_EMBEDDINGS_W",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-508_RUVECTOR_MANIFEST_RUVECTOR_ONNX_EMBEDDINGS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-509_RUVECTOR_MANIFEST_PRIME_RADIANT_CATEGORY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-510_RUVECTOR_MANIFEST_PRIME_RADIANT_ADVANCED_WAS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-511_RUVECTOR_MANIFEST_RUVLLM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-512_RUVECTOR_MANIFEST_RUVLLM_ESP32_FLASH",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-513_RUVECTOR_MANIFEST_RUVLLM_ESP32",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-514_RUVECTOR_MANIFEST_RVF_DESKTOP",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-515_RUVECTOR_MANIFEST_SPIKING_NETWORK",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-516_RUVECTOR_MANIFEST_ULTRA_LOW_LATENCY_SIM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-517_RUVECTOR_MANIFEST_EXAMPLES_VIBECAST_7SENSE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-518_RUVECTOR_MANIFEST_SEVENSENSE_ANALYSIS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-519_RUVECTOR_MANIFEST_SEVENSENSE_API",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-520_RUVECTOR_MANIFEST_SEVENSENSE_AUDIO",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-521_RUVECTOR_MANIFEST_SEVENSENSE_BENCHES",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-522_RUVECTOR_MANIFEST_SEVENSENSE_CORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-523_RUVECTOR_MANIFEST_SEVENSENSE_EMBEDDING",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-524_RUVECTOR_MANIFEST_SEVENSENSE_INTERPRETATION",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-525_RUVECTOR_MANIFEST_SEVENSENSE_LEARNING",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-526_RUVECTOR_MANIFEST_SEVENSENSE_VECTOR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-527_RUVECTOR_MANIFEST_PERFORMANCE_REPORT",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-528_RUVECTOR_MANIFEST_VIBECAST_TESTS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-529_RUVECTOR_MANIFEST_RUVECTOR_IOS_WASM",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-530_RUVECTOR_MANIFEST_HNSW_RS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-531_RUVECTOR_MANIFEST_HNSW_RS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-532_RUVECTOR_MANIFEST_RUVECTOR_ATTENTION_INTEGRA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-533_RUVECTOR_NAMED_SURFACE_RUVECTOR_HNSW_REPAIR",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-534_RUVECTOR_NAMED_SURFACE_RUVECTOR_SPARSE_INFER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-535_RUVECTOR_NAMED_SURFACE_RUVECTOR_ATTENTION_CL",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-536_RUVECTOR_NAMED_SURFACE_RUVECTOR_MINCUT_BRAIN",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-537_RUVECTOR_NAMED_SURFACE_RUVECTOR_TEMPORAL_TEN",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-538_RUVECTOR_NAMED_SURFACE_RUVECTOR_TIMESFM_FORE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-539_RUVECTOR_NAMED_SURFACE_RUVLLM_BRIDGE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-540_RUVECTOR_NAMED_SURFACE_RUVLLM_EMBEDDER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-541_RUVECTOR_NAMED_SURFACE_RUVLLM_PI_WORKER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-542_RUVECTOR_NAMED_SURFACE_MCP_BRAIN_SERVER_LOCA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-543_RUVECTOR_NAMED_SURFACE_RUVECTOR_HAILO_EMBED",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-544_RUVECTOR_NAMED_SURFACE_RUVECTOR_HAILO_WORKER",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-545_RUVECTOR_NAMED_SURFACE_RUVECTOR_HAILO_STATS",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-546_RUVECTOR_NAMED_SURFACE_RUVECTOR_MMWAVE_BRIDG",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-547_LIFEOS_AGENTDB_SCHEMA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "COMPONENT-548_LIFEOS_RVF_SCHEMA",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "CURRENCY-AGENTDB",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-AGENTIC_FLOW",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-AGENTIC_QE",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-CLAUDE_FLOW",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-CLAUDE_FLOW_CLI",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-CLAUDE_FLOW_MCP",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-CLAUDE_FLOW_MEMORY",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-CLAUDE_FLOW_NEURAL",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-CLAUDE_FLOW_SHARED",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-QUDAG",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUFLO",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_ATTENTION",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_ATTENTION_UNIFIED_WASM",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_ATTENTION_WASM",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_CLI",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_CORE",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_GNN",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_GNN_WASM",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_GRAPH_TRANSFORMER_WASM",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_MATH_WASM",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_ONNX_EMBEDDINGS_WASM",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_POSTGRES_CLI",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_ROUTER",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_RUVLLM",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_RVF",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_SONA",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVECTOR_WASM",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "CURRENCY-RUVLLM_ESP32",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "DIAGRAM-D01_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D02_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D03_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D04_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D05_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D06_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D07_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D08_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D09_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D10_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D11_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D12_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D13_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D14_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D15_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D16_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D17_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D18_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D19_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D20_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D21_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D22_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D23_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "DIAGRAM-D24_ATLAS_ENTRY",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "EF-001_SCAN_PACKAGE",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "EF-002_GAP_REPORT",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "EF-003_APPLY_FRAMEWORK",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "EF-004_GENERATE_TASK_GRAPH",
    "reason": "implementation scope is command_and_verification_passed"
  },
  {
    "task_id": "EF-005_VALIDATE_TASK_GRAPH",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "EF-006_TASK_GRAPH_TO_PACKETS",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "EF-007_GOAL_LOOP",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "INV-001_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "INV-002_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "INV-003_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-004_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-005_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-006_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-007_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-008_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-009_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-010_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-011_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "INV-012_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-013_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "INV-014_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-015_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "INV-016_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-017_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-018_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "INV-019_OPERATIONAL_INVARIANT",
    "reason": "implementation scope is declared_live_probe_passed"
  },
  {
    "task_id": "MAINT-500_README_NAV_BACKTRACE",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "MAINT-501_RESTORE_PROOF_TEMPLATE",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "MAINT-502_LIVE_MANIFEST_VERIFICATION_SYNC",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "MAINT-503_CODEX_FINAL_PROMPT",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "PIPELINE-001_PHYSICAL_PIPELINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-002_PHYSICAL_PIPELINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-003_PHYSICAL_PIPELINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-004_PHYSICAL_PIPELINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-005_PHYSICAL_PIPELINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-006_PHYSICAL_PIPELINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-007_PHYSICAL_PIPELINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "PIPELINE-008_PHYSICAL_PIPELINE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REL-400_PACKAGE_ARCHIVE",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REL-401_HANDOFF",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-010_CONTRACT_LOCK",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-020_ENVCTL_DB_SCHEMA",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "REQ-021_ENVCTL_TARGET_REGISTRY",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-022_ENVCTL_RUN_LEDGER",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-023_ENVCTL_OPERATION_STATE",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-024_ENVCTL_ARTIFACT_REGISTRY",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "REQ-025_ENVCTL_VALIDATION_EVIDENCE",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "REQ-026_ENVCTL_ROLLBACK_CHECKPOINTS",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-027_ENVCTL_REPLAY_ENGINE",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-028_ENVCTL_AGENT_CONTROL_API",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-030_PLUGIN_PROTOCOL_MANIFEST",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-031_PLUGIN_COMMAND_SURFACE",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-032_PLUGIN_LIVE_VISUALS",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-033_PLUGIN_HUMAN_APPROVAL",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-034_PLUGIN_STATUS_STREAMS",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "REQ-040_SHARED_PROTOCOL_SCHEMAS",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "REQ-041_TWO_REPO_INTEGRATION",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "REQ-042_FILESYSTEM_BOUNDS",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "REQ-043_SECURITY_REDACTION",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "REQ-044_INSTALL_BOOTSTRAP",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "REQ-045_RUN_REPLAY",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "REQ-200_FLEXNETOS_TARGET_DESCRIPTOR",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "REQ-201_FLEXNETOS_LIFEOS_COMPARISON",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "REQ-202_FLEXNETOS_ADAPTER_RECIPE",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "REVIEW-R01_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R02_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R03_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R04_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R05_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R06_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R07_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R08_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R09_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R10_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R11_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R12_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R13_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R14_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R15_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R16_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R17_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R18_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "REVIEW-R19_LEDGER_ROW",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-001_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-002_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-003_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-004_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-005_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-006_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-007_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-008_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-009_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-010_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-011_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-012_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-013_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-014_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-015_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-016_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-017_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-018_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-019_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-020_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "RULE-021_HARD_EXECUTION_RULE",
    "reason": "implementation scope is not_claimed"
  },
  {
    "task_id": "VER-300_UNIT_VALIDATION",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "VER-301_SQL_SCHEMA_TEST",
    "reason": "implementation scope is runner_command_completed"
  },
  {
    "task_id": "VER-302_PACKET_SCHEMA_VALIDATION",
    "reason": "terminal completion does not affirm exact packet execution"
  },
  {
    "task_id": "VER-303_GOAL_LOOP_COMPUTE",
    "reason": "terminal completion does not affirm exact packet execution"
  }
]
